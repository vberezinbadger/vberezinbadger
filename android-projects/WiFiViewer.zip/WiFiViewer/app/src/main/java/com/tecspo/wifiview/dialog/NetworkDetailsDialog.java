package com.tecspo.wifiview.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.tecspo.wifiview.R;
import com.tecspo.wifiview.model.WiFiNetwork;

import java.util.ArrayList;
import java.util.List;

public class NetworkDetailsDialog extends DialogFragment {
    private WiFiNetwork network;

    public static NetworkDetailsDialog newInstance(WiFiNetwork network) {
        NetworkDetailsDialog dialog = new NetworkDetailsDialog();
        dialog.network = network;
        return dialog;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_network_details, null);

        setupViews(view);
        setupChart(view);

        return builder.setView(view)
                .setPositiveButton("OK", null)
                .create();
    }

    private void setupViews(View view) {
        ((TextView) view.findViewById(R.id.networkName)).setText(network.getSsid());
        ((TextView) view.findViewById(R.id.bssidText)).setText(network.getBssid());
        ((TextView) view.findViewById(R.id.signalText)).setText(network.getSignalStrength() + " dBm");
        ((TextView) view.findViewById(R.id.frequencyText)).setText(network.getFrequency() + " MHz");
        ((TextView) view.findViewById(R.id.securityText)).setText(network.getCapabilities());
    }

    private void setupChart(View view) {
        LineChart chart = view.findViewById(R.id.signalChart);
        List<Entry> entries = new ArrayList<>();
        List<Integer> history = network.getSignalHistory();

        for (int i = 0; i < history.size(); i++) {
            entries.add(new Entry(i, history.get(i)));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Сила сигнала (dBm)");
        dataSet.setDrawValues(false);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);
        chart.getDescription().setEnabled(false);
        chart.invalidate();
    }
}
