package com.tecspo.wifiview;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.tecspo.wifiview.adapter.WiFiNetworkAdapter;
import com.tecspo.wifiview.dialog.NetworkDetailsDialog;
import com.tecspo.wifiview.model.WiFiNetwork;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private WifiManager wifiManager;
    private WiFiNetworkAdapter adapter;
    private SwipeRefreshLayout swipeRefresh;
    private SwitchMaterial wifiSwitch;
    private Handler handler = new Handler();
    private static final int PERMISSIONS_REQUEST_CODE = 100;
    private static final long SCAN_INTERVAL = 10000; // 10 секунд

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        setupViews();
        checkPermissions();
        startPeriodicScan();
    }

    private void setupViews() {
        RecyclerView recyclerView = findViewById(R.id.wifiList);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        wifiSwitch = findViewById(R.id.wifiSwitch);

        adapter = new WiFiNetworkAdapter(new ArrayList<>(), this::showNetworkDetails);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        wifiSwitch.setChecked(wifiManager.isWifiEnabled());
        wifiSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            wifiManager.setWifiEnabled(isChecked);
            if (isChecked) {
                scanWifiNetworks();
            }
        });

        swipeRefresh.setOnRefreshListener(this::scanWifiNetworks);
    }

    private void scanWifiNetworks() {
        if (!checkPermissions() || wifiManager == null) {
            Toast.makeText(this, "Нет необходимых разрешений или WiFi недоступен", Toast.LENGTH_SHORT).show();
            if (swipeRefresh != null) {
                swipeRefresh.setRefreshing(false);
            }
            return;
        }

        try {
            wifiManager.startScan();
            List<ScanResult> results = wifiManager.getScanResults();
            if (results != null) {
                List<WiFiNetwork> networks = new ArrayList<>();
                for (ScanResult result : results) {
                    if (result.SSID != null && !result.SSID.isEmpty()) {
                        WiFiNetwork network = findExistingNetwork(result.BSSID);
                        if (network == null) {
                            network = new WiFiNetwork(
                                result.SSID,
                                result.BSSID,
                                result.level,
                                result.capabilities != null ? result.capabilities : "",
                                result.frequency
                            );
                        }
                        network.addSignalStrength(result.level);
                        networks.add(network);
                    }
                }
                if (adapter != null) {
                    adapter.updateNetworks(networks);
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка сканирования: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (swipeRefresh != null) {
                swipeRefresh.setRefreshing(false);
            }
        }
    }

    private WiFiNetwork findExistingNetwork(String bssid) {
        if (adapter == null || bssid == null) {
            return null;
        }
        try {
            for (int i = 0; i < adapter.getItemCount(); i++) {
                WiFiNetwork network = adapter.getNetwork(i);
                if (network != null && bssid.equals(network.getBssid())) {
                    return network;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_CODE);
            return false;
        }
        return true;
    }

    private void startPeriodicScan() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (wifiManager.isWifiEnabled()) {
                    scanWifiNetworks();
                }
                handler.postDelayed(this, SCAN_INTERVAL);
            }
        }, SCAN_INTERVAL);
    }

    private void showNetworkDetails(WiFiNetwork network) {
        if (network != null) {
            NetworkDetailsDialog dialog = NetworkDetailsDialog.newInstance(network);
            dialog.show(getSupportFragmentManager(), "network_details");
        }
    }

    @Override
    protected void onDestroy() {
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }
}
