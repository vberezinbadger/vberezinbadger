package com.tecspo.wifiview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.tecspo.wifiview.R;
import com.tecspo.wifiview.model.WiFiNetwork;
import java.util.ArrayList;
import java.util.List;

public class WiFiNetworkAdapter extends RecyclerView.Adapter<WiFiNetworkAdapter.ViewHolder> {
    private List<WiFiNetwork> networks;
    private OnNetworkClickListener listener;

    public interface OnNetworkClickListener {
        void onNetworkClick(WiFiNetwork network);
    }

    public WiFiNetworkAdapter(List<WiFiNetwork> networks, OnNetworkClickListener listener) {
        this.networks = networks;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_wifi_network, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        WiFiNetwork network = networks.get(position);
        holder.ssidText.setText(network.getSsid());
        holder.signalStrengthText.setText("Сигнал: " + network.getSignalStrength() + " dBm");
        holder.statusText.setText(network.getStatus());
        
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onNetworkClick(network);
            }
        });
    }

    @Override
    public int getItemCount() {
        return networks.size();
    }

    public void updateNetworks(List<WiFiNetwork> newNetworks) {
        if (newNetworks != null) {
            this.networks = new ArrayList<>(newNetworks);
        } else {
            this.networks = new ArrayList<>();
        }
        notifyDataSetChanged();
    }

    public WiFiNetwork getNetwork(int position) {
        if (position >= 0 && position < networks.size()) {
            return networks.get(position);
        }
        return null;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView ssidText, signalStrengthText, statusText;

        ViewHolder(View view) {
            super(view);
            ssidText = view.findViewById(R.id.ssidText);
            signalStrengthText = view.findViewById(R.id.signalStrengthText);
            statusText = view.findViewById(R.id.statusText);
        }
    }
}
