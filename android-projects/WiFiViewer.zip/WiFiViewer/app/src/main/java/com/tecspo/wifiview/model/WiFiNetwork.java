package com.tecspo.wifiview.model;

import java.util.ArrayList;
import java.util.List;

public class WiFiNetwork {
    private String ssid;
    private String bssid;
    private int signalStrength;
    private String capabilities;
    private int frequency;
    private String status;
    private List<Integer> signalHistory = new ArrayList<>();
    private static final int MAX_HISTORY_SIZE = 30;

    public WiFiNetwork(String ssid, String bssid, int signalStrength, String capabilities, int frequency) {
        this.ssid = ssid;
        this.bssid = bssid;
        this.signalStrength = signalStrength;
        this.capabilities = capabilities;
        this.frequency = frequency;
    }

    // Геттеры
    public String getSsid() { return ssid; }
    public String getBssid() { return bssid; }
    public int getSignalStrength() { return signalStrength; }
    public String getCapabilities() { return capabilities; }
    public int getFrequency() { return frequency; }
    public String getStatus() { return status; }
    
    public void setStatus(String status) { this.status = status; }

    public void addSignalStrength(int strength) {
        if (signalHistory == null) {
            signalHistory = new ArrayList<>();
        }
        signalHistory.add(strength);
        if (signalHistory.size() > MAX_HISTORY_SIZE) {
            signalHistory.remove(0);
        }
    }

    public List<Integer> getSignalHistory() {
        return signalHistory != null ? signalHistory : new ArrayList<>();
    }
}
