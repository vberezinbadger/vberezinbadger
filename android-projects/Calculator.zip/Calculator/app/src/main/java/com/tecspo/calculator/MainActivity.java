package com.tecspo.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView resultText;
    private String currentNumber = "";
    private String operator = "";
    private double firstNumber = 0;
    private boolean isNewNumber = true;

    @Override // Модная спайкучка, а на башке колючка
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultText = findViewById(R.id.result_text);
        resultText.setText("0");
    }

    // От Шведова: вам полагается 2 тульских пряника.
    // P.s. от Слинько (он не придумал, что тут написать)

    public void onButtonClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();

        switch (buttonText) {
            case "C":
                currentNumber = "";
                operator = "";
                firstNumber = 0;
                isNewNumber = true;
                resultText.setText("0");
                break;

            case "+/-":
                if (!currentNumber.isEmpty()) {
                    double number = Double.parseDouble(currentNumber);
                    number = -number;
                    currentNumber = String.valueOf(number);
                    resultText.setText(formatNumber(number));
                }
                break;

            case "%":
                if (!currentNumber.isEmpty()) {
                    double number = Double.parseDouble(currentNumber);
                    number = number / 100;
                    currentNumber = String.valueOf(number);
                    resultText.setText(formatNumber(number));
                }
                break;

            case "=":
                if (!currentNumber.isEmpty() && !operator.isEmpty()) {
                    calculateResult();
                }
                break;

            case "+":
            case "-":
            case "×":
            case "÷":
                if (!currentNumber.isEmpty()) {
                    if (!operator.isEmpty()) {
                        calculateResult();
                    }
                    operator = buttonText;
                    firstNumber = Double.parseDouble(currentNumber);
                    isNewNumber = true;
                }
                break;

            case ".":
                if (isNewNumber) {
                    currentNumber = "0";
                    isNewNumber = false;
                }
                if (!currentNumber.contains(".")) {
                    currentNumber += ".";
                    resultText.setText(currentNumber);
                }
                break;

            default:
                if (isNewNumber) {
                    currentNumber = buttonText;
                    isNewNumber = false;
                } else {
                    currentNumber += buttonText;
                }
                resultText.setText(currentNumber);
                break;
        }
    }

    private void calculateResult() {
        double secondNumber = Double.parseDouble(currentNumber);
        double result = 0;

        switch (operator) {
            case "+":
                result = firstNumber + secondNumber;
                break;
            case "-":
                result = firstNumber - secondNumber;
                break;
            case "×":
                result = firstNumber * secondNumber;
                break;
            case "÷":
                if (secondNumber != 0) {
                    result = firstNumber / secondNumber;
                } else {
                    resultText.setText("Error");
                    return;
                }
                break;
        }

        currentNumber = String.valueOf(result);
        resultText.setText(formatNumber(result));
        operator = "";
        isNewNumber = true;
    }

    private String formatNumber(double number) {
        if (number == (long) number) {
            return String.format("%d", (long) number);
        }
        return String.format("%s", number);
    }
}
