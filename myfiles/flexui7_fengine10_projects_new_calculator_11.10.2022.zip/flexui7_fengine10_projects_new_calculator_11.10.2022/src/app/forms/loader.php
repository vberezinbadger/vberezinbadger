<?php
namespace app\forms;

use php\gui\framework\AbstractForm;


class loader extends AbstractForm
{

}