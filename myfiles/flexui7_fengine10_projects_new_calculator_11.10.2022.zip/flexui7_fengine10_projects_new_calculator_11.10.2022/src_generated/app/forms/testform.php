<?php
namespace app\forms;

use action\Animation;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXKeyEvent; 
use php\gui\event\UXMouseEvent; 


class testform extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        Animation::fadeOut($this, 80);
        waitAsync(500, function () use ($e, $event) {
            app()->shutdown();
        });
    }

    /**
     * @event button12.action 
     */
    function doButton12Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel->hide();

        
    }


    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel->show();

        
    }

    /**
     * @event click-Left 
     */
    function doClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panelAlt->hide();

        
    }


    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panelAlt->show();

        
    }

    /**
     * @event editAlt.keyUp-Enter 
     */
    function doEditAltKeyUpEnter(UXKeyEvent $e = null)
    {    
        if ($this->editAlt->text == "calculator") {
            app()->showForm('MainForm');
        }
        
        if ($this->editAlt->text == "calculator -blackTheme") {
            app()->showForm('MainFormDark');
        }
    }

    /**
     * @event edit.keyUp-Enter 
     */
    function doEditKeyUpEnter(UXKeyEvent $e = null)
    {    
        $this->rect10->fillColor = $this->edit->text;
    }

    /**
     * @event edit3.keyUp-Enter 
     */
    function doEdit3KeyUpEnter(UXKeyEvent $e = null)
    {
        $zagolovok = $this->edit3->text;
        
        $this->form('MainForm')->label->text = $zagolovok;
        $this->form('MainFormDark')->label->text = $zagolovok;
    }


}
