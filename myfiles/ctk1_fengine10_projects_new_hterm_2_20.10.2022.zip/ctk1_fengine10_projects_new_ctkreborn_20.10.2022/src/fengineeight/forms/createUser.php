<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class createUser extends AbstractForm
{

    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $e = null)
    {    
        $usernameNew = $this->edit->text;
        
        if (File::of('workspace')->isDirectory()) {
            fs::makeDir('workspace/users/' . $usernameNew . '');
            File::of('workspace/users/' . $usernameNew . '/usermgr.username')->createNewFile();
            file_put_contents('workspace/users/' . $usernameNew . '/usermgr.username', "" . $usernameNew . "");
            $this->loadForm('createPassword', false, true);
            $this->label6->visible = false;
        } else {
            $this->label6->visible = true;
        }
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('createUser');
        $this->edit->text = '';
        $this->label6->visible = false;
    }


}
