<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class settings extends AbstractForm
{


    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('doneCreatUser');
    }

    /**
     * @event image5.click-Left 
     */
    function doImage5ClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('doneCreatUser');
    }

    /**
     * @event link.action 
     */
    function doLinkAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event linkAlt.action 
     */
    function doLinkAltAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event link3.action 
     */
    function doLink3Action(UXEvent $e = null)
    {    
        
    }








}
