<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class videoplayer extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        $this->player->play();
        waitAsync(1200, function () use ($e, $event) {
                Animation::fadeOut($this->label, 250);
        });
        Animation::fadeTo($this->image3, 1, 1.0);
        $this->image->visible = false;
        $this->image5->visible = true;
    }

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        $this->player->volume = 1.0;
        $this->sliderAlt->value = 100;
    }

    /**
     * @event image3.click-Left 
     */
    function doImage3ClickLeft(UXMouseEvent $e = null)
    {    
        $this->player->stop();
        Animation::fadeIn($this->label, 1);
        $this->image5->hide();
        $this->image->show();
        Animation::fadeTo($this->image3, 1, 0.5);
        $this->image3->enabled = false;
    }

    /**
     * @event image4.click-Left 
     */
    function doImage4ClickLeft(UXMouseEvent $e = null)
    {    
        $this->title = 'Ожидание файла - FLEXengine Player';
        
        $dialog = new UXFileChooser();
        $dialog->extensionFilters = [
            ['extensions' => ['*.mp4', '*.flv'], 'description' =>'Видео-формат']
        ];

        if ($file = $dialog->showOpenDialog()){
            $this->player->open($file);
            $this->title = 'Файл: '. $file .' - FLEXengine Player';
            $this->image->visible = !$this->image->visible;
            $this->image5->visible = !$this->image5->visible;
            Animation::fadeTo($this->image5, 0, 1.0);
            Animation::fadeTo($this->image3, 0, 1.0);
            $this->image5->enabled = true;
            $this->image->enabled = true;
            $this->image3->enabled = true;
            Animation::fadeTo($this->image, 1, 1.0);
            $this->player->position = $this->slider->value;
            $this->label->text = $file;
            Animation::fadeIn($this->label, 1);
            waitAsync(1200, function () use ($e, $event) {
                Animation::fadeOut($this->label, 250);
            });
        }
    }

    /**
     * @event image5.click-Left 
     */
    function doImage5ClickLeft(UXMouseEvent $e = null)
    {
        $this->player->pause();
        Animation::fadeIn($this->label, 1);
        $this->image->visible = true;
        $this->image5->visible = false;
        $this->image->enabled = true;
        Animation::fadeTo($this->image, 1, 1.0);
        
    }


    /**
     * @event image7.click-Left 
     */
    function doImage7ClickLeft(UXMouseEvent $e = null)
    {
        $this->player->volume = 0.0;
        $this->sliderAlt->value = 0;
    }

    /**
     * @event sliderAlt.mouseUp-Left 
     */
    function doSliderAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->player->volume = $this->sliderAlt->value / 100;
    }

    /**
     * @event slider.mouseUp-Left 
     */
    function doSliderMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->player->position = $this->slider->value;
    }

    /**
     * @event image6.click-Left 
     */
    function doImage6ClickLeft(UXMouseEvent $e = null)
    {    
        $this->getContextForm()->fullScreen = true;
        $this->image6->visible = !$this->image6->visible;
        $this->image8->visible = !$this->image8->visible;
    }

    /**
     * @event image8.click-Left 
     */
    function doImage8ClickLeft(UXMouseEvent $e = null)
    {    
        $this->getContextForm()->fullScreen = false;
        $this->image6->visible = !$this->image6->visible;
        $this->image8->visible = !$this->image8->visible;
    }

    /**
     * @event keyUp-Esc 
     */
    function doKeyUpEsc(UXKeyEvent $e = null)
    {    
        $this->getContextForm()->fullScreen = false;
        $this->image6->visible = !$this->image6->visible;
        $this->image8->visible = !$this->image8->visible;
    }

    /**
     * @event keyUp-F 
     */
    function doKeyUpF(UXKeyEvent $e = null)
    {    
        $this->getContextForm()->fullScreen = true;
        $this->image6->visible = !$this->image6->visible;
        $this->image8->visible = !$this->image8->visible;
    }

    /**
     * @event image9.click-Left 
     */
    function doImage9ClickLeft(UXMouseEvent $e = null)
    {
        $this->image9->visible = false;
        $this->image10->visible = true;
        $this->alwaysOnTop = true;        
        
    }

    /**
     * @event image10.click-Left 
     */
    function doImage10ClickLeft(UXMouseEvent $e = null)
    {
        $this->image9->visible = true;
        $this->image10->visible = false;
        $this->alwaysOnTop = false; 
        
    }





}
