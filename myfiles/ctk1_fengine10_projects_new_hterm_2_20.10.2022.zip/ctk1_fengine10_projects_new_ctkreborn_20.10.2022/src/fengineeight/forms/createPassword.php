<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class createPassword extends AbstractForm
{

    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $e = null)
    {    
        $usernameNew = $this->form('createUser')->edit->text;
        $passwordNew = $this->passwordField->text;
        
        if (File::of('workspace')->isDirectory()) {
            File::of('workspace/users/' . $usernameNew . '/usermgr.password')->createNewFile();
            file_put_contents('workspace/users/' . $usernameNew . '/usermgr.password', "" . $passwordNew . "");
            $this->loadForm('doneCreatUser', false, true);
            $this->label6->visible = false;
        } else {
            $this->label6->visible = true;
        }
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('createPassword');
        $this->edit->text = '';
        $this->label6->visible = false;
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->label3->text = "Создание пароля для: " . $this->form('createUser')->edit->text . "";
    }

}
