<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class speak extends AbstractForm
{

}