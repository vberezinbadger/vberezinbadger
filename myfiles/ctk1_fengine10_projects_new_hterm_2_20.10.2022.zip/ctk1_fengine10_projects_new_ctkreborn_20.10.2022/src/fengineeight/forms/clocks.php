<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class clocks extends AbstractForm
{


    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {    
        
    }



    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
        
    }




    /**
     * @event circle10.mouseEnter 
     */
    function doCircle10MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.mouseExit 
     */
    function doCircle10MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {    
        
    }




    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }



    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle6.mouseEnter 
     */
    function doCircle6MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle6.mouseExit 
     */
    function doCircle6MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle6.click-Left 
     */
    function doCircle6ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event circle11.mouseEnter 
     */
    function doCircle11MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle11.mouseExit 
     */
    function doCircle11MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle11.click-Left 
     */
    function doCircle11ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label4.construct 
     */
    function doLabel4Construct(UXEvent $e = null)
    {    
        
    }









































}
