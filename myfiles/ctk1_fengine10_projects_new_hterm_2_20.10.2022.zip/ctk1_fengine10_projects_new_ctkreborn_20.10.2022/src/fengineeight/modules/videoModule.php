<?php
namespace fengineeight\modules;

use std, gui, framework, fengineeight;


class videoModule extends AbstractModule
{

    /**
     * @event fileChooser.action 
     */
    function doFileChooserAction(ScriptEvent $e = null)
    {    
        $dialog = new UXFileChooser();
        $dialog->extensionFilters = [
            ['extensions' => ['*.mp4', '*.flv'], 'description' =>'Video (mp4, flv)']
        ];

        if ($file = $dialog->showOpenDialog()){
            $this->player->open($file);
        }
    }

    /**
     * @event player.play 
     */
    function doPlayerPlay(ScriptEvent $e = null)
    {    
        $this->slider->value = $this->player->position;
    }


}
