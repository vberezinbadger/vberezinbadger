<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use php\time\Time;
use action\Animation; 


class forColor extends AbstractForm
{

    $version = "2.0.010";
    






    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event edit.keyUp-Enter 
     */
    function doEditKeyUpEnter(UXKeyEvent $e = null)
    {    
        $command = $this->edit->text;
        
        switch($command) {
            
            case "clear":
                    $this->log->text = "Очистка консоли выполнена! \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: clear. \n";
                    echo "\n[TERM]: Cleared! \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: clear.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: output cleared!\r\n", FILE_APPEND);
                    break;
            
            case "about":
                    $this->log->text .= "\n~: about";
                    $this->log->text .= "\nHentai Terminal Developer Preview \nВерсия: 2.0.010. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: about. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: output version: DEVELOPER_PROJECT_CODENAME_RAMPAGE_2.0.010_DEV_CTK_BUILD.\r\n", FILE_APPEND);
                    break;
                    
            case "about -core":
                    $this->log->text .= "\n~: about -core";
                    $this->log->text .= "\nИнформация о ядре. \nЯдро: Anaconda Shell (на базе Hentai Bash и OctopusSH). \nВерсия ядра: 2.0.010_dev. \nТерминал: hterm-windows. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: about -core. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about -core.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "Anaconda Shell, v2.0.010_dev.\r\n", FILE_APPEND);
                    break;
                    
            case "about -gui":
                    $this->log->text .= "\n~: about -gui";
                    $this->log->text .= "\nМеню о программе в графическом режиме. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand with args: about -gui. \n";
                    $this->panelAlt->show();
                    waitAsync(300, function () use ($e, $event) {
                    Animation::fadeIn($this->panelAlt, 130);
                    });
                    echo "\n[CTK Debug]: loaded formInfo: about.form. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about -core.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: loaded formInfo: about.form.\r\n", FILE_APPEND);
                    break;
                    
            case "exit":
                    $this->log->text .= "\n~: exit";
                    $this->log->text .= "\nВыход из Hentai Terminal, пожалуйста подождите...";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: exit.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: unloading forms...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: unloading bootstrap...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exiting terminal session...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[SESSION]: user session stopped!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[HBASH]: exiting modules...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: saving logs... done!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exited!\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting FLEXwindow...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Saving loader logs...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Stopping plugins and modules...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    waitAsync(700, function () use ($e, $event) {
                        $this->log->text .= "\nСохранение записи состояния работы в лог-файл терминала (termLog.txt)...";
                        waitAsync(700, function () use ($e, $event) {
                            $this->log->text .= "\nОстановка модулей...";
                            waitAsync(800, function () use ($e, $event) {
                                $this->log->text .= "\nОстановка работы Hentai Bash Reborn (Anaconda Shell)...";
                                waitAsync(560, function () use ($e, $event) {
                                    $this->log->text .= "\nВыход из терминальной среды...";
                                    waitAsync(1200, function () use ($e, $event) {
                                        app()->shutdown();
                                    });});});});});
                    break;
                    
            case "time":
                    $this->log->text .= "\n~: time";
                    $this->log->text .= "\nТекущее время: " . Time::now()->toString('HH:mm') . ". \n";
                    $this->edit->text = "";
                    break;
                    
            case "date":
                    $this->log->text .= "\n~: date";
                    $this->log->text .= "\nТекущая дата: " . Time::now()->toString('dd.MM.yyyy') . ". \n";
                    $this->edit->text = "";
                    break;        
                    
            case "pkg run time":
                    $this->log->text .= "\n~: pkg run time";
                    $this->log->text .= "\nЗапуск пакета termTime... \n";
                    $this->edit->text = "";
                    $this->panel3->show();
                    break;
                    
            case "tasks kill time":
                    $this->log->text .= "\n~: tasks kill time";
                    $this->log->text .= "\nПакет termTime был остановлен. Точка остановки: hbashCmd/tasks.methodKill. \n";
                    $this->edit->text = "";
                    $this->panel3->hide();
                    break;
                    
            case "tasks kill":
                    $this->log->text .= "\n~: tasks kill";
                    $this->log->text .= "\nДля остановки задачи (пакета), введите его название.";
                    $this->log->text .= "\nПример: tasks kill [название_пакета]. \n";
                    $this->edit->text = "";
                    break; 
                    
            case "tasks":
                    $this->log->text .= "\n~: tasks";
                    $this->log->text .= "\nОтсутствуют аргументы для команды.";
                    $this->log->text .= "\nЧтобы открыть информацию по данной команде, введите help -tasks. \n";
                    $this->edit->text = "";
                    break;
                    
            case "version -check":
                    $version = "2.0.010";
                    $sversion = file_get_contents('https://kolibra.site/flex/hterm/version.txt');
                    $changelog = file_get_contents('https://kolibra.site/flex/hterm/changelog/lastchangelog.txt');
                    
                    if($version == $sversion) {
                        $this->log->text .= "\n~: version -check";
                        $this->log->text .= "\nВерсия сервера: " . $sversion . "";
                        $this->log->text .= "\nВерсия клиента с версией сервера совпадает. Поиск и установка обновлений не требуется. \n";
                        $this->edit->text = "";
                    } else {
                        $this->log->text .= "\n~: version -check";
                        $this->log->text .= "\nВерсия сервера: " . $sversion . "";
                        $this->log->text .= "\nВерсия клиента устарела. Чтобы получить доступ к новейшим функциям, необходимо обновиться до свежей версии Hentai Terminal. \n";
                        $this->edit->text = "";
                        $this->textArea->text = $changelog;
                        $this->label25->text = $sversion;
                        $this->panel4->show();
                        waitAsync(300, function () use ($e, $event) {
                        Animation::fadeIn($this->panel4, 130);
                        });
                    }   
                    break;
                    
            case "version":
                    $this->log->text .= "\n~: version";
                    $this->log->text .= "\n2.0.010 \n";
                    $this->edit->text = "";
                    break;
                    
            case "config":
                    $this->log->text .= "\n~: config";
                    $this->log->text .= "\nConfig Manager, версия: 1.0 \nИспользование: \n- config [параметр конфига] [true|false]: включение или отключение опции \n- config help: руководство до использованию Config Manager \n- config list: все параметры, доступные для данного приложения \n";
                    $this->edit->text = "";
                    break;
                    
            case "config list":
                    $this->log->text .= "\n~: config list";
                    $this->log->text .= "\nВсе параметры для Hentai Terminal: \n- noCircleWindow: управление закруглениями окон и фреймов \n";
                    $this->edit->text = "";
                    break;          
            
            case "config noCircleWindow -true":
                    $this->log->text .= "\n~: config noCircleWindow -true";
                    $this->log->text .= "\nОтключение загругления окон и фреймов: включено.\n";
                    $this->edit->text = "";
                    File::of('config/noCircleWindow.true')->createNewFile();
                    if (File::of('config/noCircleWindow.true')->isFile()) {
                        $this->rect8->arcWidth = 0;
                        $this->rect8->arcHeight = 0;
        
                        $this->rectAlt->arcWidth = 0;
                        $this->rectAlt->arcHeight = 0;
        
                        $this->rect->arcWidth = 0;
                        $this->rect->arcHeight = 0;
        
                        $this->panelAlt->borderRadius = 0;
        
                        $this->rect24->arcWidth = 0;
                        $this->rect24->arcHeight = 0;
        
                        $this->rect27->arcWidth = 0;
                        $this->rect27->arcHeight = 0;
        
                        $this->rect26->arcWidth = 0;
                        $this->rect26->arcHeight = 0;
            
                        $this->panel5->borderRadius = 0;
            
                        $this->rect38->arcWidth = 0;
                        $this->rect38->arcHeight = 0;
                    }
                    break;
                    
            case "config noCircleWindow -false":
                    $this->log->text .= "\n~: config noCircleWindow -false";
                    $this->log->text .= "\nОтключение загругления окон и фреймов: отключено.\n";
                    $this->edit->text = "";
                    unlink('config/noCircleWindow.true');
                    if (!File::of('config/noCircleWindow.true')->isFile()) {
                        $this->rect8->arcWidth = 18;
                        $this->rect8->arcHeight = 18;
        
                        $this->rectAlt->arcWidth = 16;
                        $this->rectAlt->arcHeight = 16;
        
                        $this->rect->arcWidth = 16;
                        $this->rect->arcHeight = 16;
        
                        $this->panelAlt->borderRadius = 9;
        
                        $this->rect24->arcWidth = 18;
                        $this->rect24->arcHeight = 18;
        
                        $this->rect27->arcWidth = 16;
                        $this->rect27->arcHeight = 16;
        
                        $this->rect26->arcWidth = 16;
                        $this->rect26->arcHeight = 16;
            
                        $this->panel5->borderRadius = 8;
            
                        $this->rect38->arcWidth = 16;
                        $this->rect38->arcHeight = 16;
                    }
                    break;
                    
            case "config newMenuTest -true":
                    $this->log->text .= "\n~: config newMenuTest -true";
                    $this->log->text .= "\nНовое меню CTK для Hentai Terminal: включено.\n";
                    $this->edit->text = "";
                    File::of('config/newMenuCTK.true')->createNewFile();
                    if (File::of('config/newMenuCTK.true')->isFile()) {
                        $this->rect5->visible = true;
                        $this->imageAlt->visible = true;
                        $this->button->visible = true;
                        $this->label->x = 104;
                    }
                    break;
                    
            case "config newMenuTest -false":
                    $this->log->text .= "\n~: config newMenuTest -false";
                    $this->log->text .= "\nНовое меню CTK для Hentai Terminal: отключено.\n";
                    $this->edit->text = "";
                    unlink('config/newMenuCTK.true');
                    if (!File::of('config/newMenuCTK.true')->isFile()) {
                        $this->rect5->visible = false;
                        $this->imageAlt->visible = false;
                        $this->button->visible = false;
                        $this->label->x = 66;
                    }
                    break;         
                    
            default:
                    $this->log->text .= "\n~: ". $command ."";
                    $this->log->text .= "\nНеверная команда. Возможно, в команде опечатка, или синтаксическая ошибка. \n";
                    $this->edit->text = "";
                    echo "\n[ERROR]: called defaultCmdMessage: noFoundCmd. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: ". $command ." (notFound).\r\n", FILE_APPEND);
                    break;               
        }
    }





    
    

    /**
     * @event circle9.mouseEnter 
     */
    function doCircle9MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle9.mouseExit 
     */
    function doCircle9MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle9.click-Left 
     */
    function doCircle9ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        $search = $this->editAlt->text;
        browse('https://yandex.ru/search/?text='. $search .'');
    }





    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect5.click-Left 
     */
    function doRect5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event image6.click 
     */
    function doImage6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect4.click 
     */
    function doRect4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label.click 
     */
    function doLabelClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect3.click 
     */
    function doRect3Click(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event rect6.click 
     */
    function doRect6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect7.click 
     */
    function doRect7Click(UXMouseEvent $e = null)
    {    
        
    }



    /**
     * @event image3.click 
     */
    function doImage3Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circleAlt.click 
     */
    function doCircleAltClick(UXMouseEvent $e = null)
    {    
        
    }














}
