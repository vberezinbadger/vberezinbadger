<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use action\Animation; 


class usrStatus extends AbstractForm
{


    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle, 130, 0.6);

        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle, 130, 0.3);

        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('usrStatus');
    }


    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        # UserManager Script Check
        
        if(File::of('workspace/users')->isDirectory()) {
            Logger::info('[FLEXengine]: Loaded loginForm!');
        } else {
            $this->loadForm('hterm');
        }
        
        # noWindowCirlceConfig Check
        
        if (File::of('config/noCircleWindow.true')->isFile()) {
            $this->rect8->arcWidth = 0;
            $this->rect8->arcHeight = 0;
        
            $this->rectAlt->arcWidth = 0;
            $this->rectAlt->arcHeight = 0;
        
            $this->rect->arcWidth = 0;
            $this->rect->arcHeight = 0;
        } else {
            $this->rect8->arcWidth = 18;
            $this->rect8->arcHeight = 18;
        
            $this->rectAlt->arcWidth = 16;
            $this->rectAlt->arcHeight = 16;
        
            $this->rect->arcWidth = 16;
            $this->rect->arcHeight = 16;
        }
    }
























}
