<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use action\Animation; 


class changeLed extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $color = $this->edit->text;
        $this->form('hterm')->cliStatus->fillColor = $color;
    }

    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('changeLed');
    }


    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        # noWindowCirlceConfig Check
        
        if (File::of('config/noCircleWindow.true')->isFile()) {
            $this->rect8->arcWidth = 0;
            $this->rect8->arcHeight = 0;
        
            $this->rectAlt->arcWidth = 0;
            $this->rectAlt->arcHeight = 0;
        
            $this->rect->arcWidth = 0;
            $this->rect->arcHeight = 0;
        } else {
            $this->rect8->arcWidth = 18;
            $this->rect8->arcHeight = 18;
        
            $this->rectAlt->arcWidth = 16;
            $this->rectAlt->arcHeight = 16;
        
            $this->rect->arcWidth = 16;
            $this->rect->arcHeight = 16;
        }
    }


























}
