<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use action\Animation; 
use action\Element; 


class noteConceptColor extends AbstractForm
{

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseDown-Left 
     */
    function doButtonAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseUp-Left 
     */
    function doButtonAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.mouseEnter 
     */
    function doButton3MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.mouseExit 
     */
    function doButton3MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.mouseDown-Left 
     */
    function doButton3MouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.mouseUp-Left 
     */
    function doButton3MouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.mouseEnter 
     */
    function doButton4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.mouseExit 
     */
    function doButton4MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.mouseDown-Left 
     */
    function doButton4MouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.mouseUp-Left 
     */
    function doButton4MouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button5.mouseEnter 
     */
    function doButton5MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button5.mouseExit 
     */
    function doButton5MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button5.mouseDown-Left 
     */
    function doButton5MouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button5.mouseUp-Left 
     */
    function doButton5MouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button6.mouseEnter 
     */
    function doButton6MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button6.mouseExit 
     */
    function doButton6MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button6.mouseDown-Left 
     */
    function doButton6MouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button6.mouseUp-Left 
     */
    function doButton6MouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->alwaysOnTop = true;
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {    
        $this->alwaysOnTop = false;
    }

    /**
     * @event circle10.mouseEnter 
     */
    function doCircle10MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.mouseExit 
     */
    function doCircle10MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button7.mouseEnter 
     */
    function doButton7MouseEnter(UXMouseEvent $e = null)
    {
        $this->rect24->strokeWidth = 2;
    }

    /**
     * @event button7.mouseExit 
     */
    function doButton7MouseExit(UXMouseEvent $e = null)
    {
        $this->rect24->strokeWidth = 1;
    }

    /**
     * @event button7.mouseDown-Left 
     */
    function doButton7MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->rect24->strokeColor = '#999999';
        $this->rect24->fillColor = '#e6e6e6';
    }

    /**
     * @event button7.mouseUp-Left 
     */
    function doButton7MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->rect24->strokeColor = '#b3b3b3';
        $this->rect24->fillColor = '#f2f2f2';
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button8.mouseEnter 
     */
    function doButton8MouseEnter(UXMouseEvent $e = null)
    {
        $this->rect19->strokeWidth = 2;
    }

    /**
     * @event button8.mouseExit 
     */
    function doButton8MouseExit(UXMouseEvent $e = null)
    {
        $this->rect19->strokeWidth = 1;
    }

    /**
     * @event button8.mouseDown-Left 
     */
    function doButton8MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->rect19->strokeColor = '#999999';
        $this->rect19->fillColor = '#e6e6e6';
    }

    /**
     * @event button8.mouseUp-Left 
     */
    function doButton8MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->rect19->strokeColor = '#b3b3b3';
        $this->rect19->fillColor = '#f2f2f2';
    }

}
