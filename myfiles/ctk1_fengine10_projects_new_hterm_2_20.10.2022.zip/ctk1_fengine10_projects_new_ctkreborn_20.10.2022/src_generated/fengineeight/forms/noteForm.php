<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use action\Animation; 
use action\Element; 


class noteForm extends AbstractForm
{

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 130, 0.1);

        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 130, 0.0);

        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 50, 0.2);

        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 50, 0.1);

        
    }

    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 130, 0.1);

        
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 130, 0.0);

        
    }

    /**
     * @event buttonAlt.mouseDown-Left 
     */
    function doButtonAltMouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 50, 0.2);

        
    }

    /**
     * @event buttonAlt.mouseUp-Left 
     */
    function doButtonAltMouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 50, 0.1);

        
    }

    /**
     * @event button3.mouseEnter 
     */
    function doButton3MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect9, 130, 0.1);

        
    }

    /**
     * @event button3.mouseExit 
     */
    function doButton3MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect9, 130, 0.0);

        
    }

    /**
     * @event button3.mouseDown-Left 
     */
    function doButton3MouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect9, 50, 0.2);

        
    }

    /**
     * @event button3.mouseUp-Left 
     */
    function doButton3MouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect9, 50, 0.1);

        
    }

    /**
     * @event button4.mouseEnter 
     */
    function doButton4MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect7, 130, 0.1);

        
    }

    /**
     * @event button4.mouseExit 
     */
    function doButton4MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect7, 130, 0.0);

        
    }

    /**
     * @event button4.mouseDown-Left 
     */
    function doButton4MouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect7, 50, 0.2);

        
    }

    /**
     * @event button4.mouseUp-Left 
     */
    function doButton4MouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect7, 50, 0.1);

        
    }

    /**
     * @event button5.mouseEnter 
     */
    function doButton5MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect10, 130, 0.1);

        
    }

    /**
     * @event button5.mouseExit 
     */
    function doButton5MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect10, 130, 0.0);

        
    }

    /**
     * @event button5.mouseDown-Left 
     */
    function doButton5MouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect10, 50, 0.2);

        
    }

    /**
     * @event button5.mouseUp-Left 
     */
    function doButton5MouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect10, 50, 0.1);

        
    }

    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle, 130, 0.6);

        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle, 130, 0.3);

        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->shutdown();

        
    }

    /**
     * @event button6.mouseEnter 
     */
    function doButton6MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 130, 0.1);

        
    }

    /**
     * @event button6.mouseExit 
     */
    function doButton6MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 130, 0.0);

        
    }

    /**
     * @event button6.mouseDown-Left 
     */
    function doButton6MouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 50, 0.2);

        
    }

    /**
     * @event button6.mouseUp-Left 
     */
    function doButton6MouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect6, 50, 0.1);

        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->button6->show();
		$this->image->hide();
		$this->buttonAlt->hide();
		$this->image8->show();

        $this->alwaysOnTop = true;
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->buttonAlt->show();
		$this->image8->hide();
		$this->button6->hide();
		$this->image->show();

        $this->alwaysOnTop = false;
    }

    /**
     * @event circle10.mouseEnter 
     */
    function doCircle10MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle9, 130, 0.6);

        
    }

    /**
     * @event circle10.mouseExit 
     */
    function doCircle10MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle9, 130, 0.3);

        
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(300, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel->show();
		waitAsync(300, function () use ($e, $event) {
			Animation::fadeIn($this->panel, 130);
		});

        
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setText($this->label, uiText($this->edit));
		Element::setText($this->labelAlt, uiText($this->textArea));
		Animation::fadeOut($this->panel, 130);
		waitAsync(300, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event button7.mouseEnter 
     */
    function doButton7MouseEnter(UXMouseEvent $e = null)
    {
        $this->rect24->strokeWidth = 2;
    }

    /**
     * @event button7.mouseExit 
     */
    function doButton7MouseExit(UXMouseEvent $e = null)
    {
        $this->rect24->strokeWidth = 1;
    }

    /**
     * @event button7.mouseDown-Left 
     */
    function doButton7MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->rect24->strokeColor = '#999999';
        $this->rect24->fillColor = '#e6e6e6';
    }

    /**
     * @event button7.mouseUp-Left 
     */
    function doButton7MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->rect24->strokeColor = '#b3b3b3';
        $this->rect24->fillColor = '#f2f2f2';
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(300, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event button8.mouseEnter 
     */
    function doButton8MouseEnter(UXMouseEvent $e = null)
    {
        $this->rect19->strokeWidth = 2;
    }

    /**
     * @event button8.mouseExit 
     */
    function doButton8MouseExit(UXMouseEvent $e = null)
    {
        $this->rect19->strokeWidth = 1;
    }

    /**
     * @event button8.mouseDown-Left 
     */
    function doButton8MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->rect19->strokeColor = '#999999';
        $this->rect19->fillColor = '#e6e6e6';
    }

    /**
     * @event button8.mouseUp-Left 
     */
    function doButton8MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->rect19->strokeColor = '#b3b3b3';
        $this->rect19->fillColor = '#f2f2f2';
    }

}
