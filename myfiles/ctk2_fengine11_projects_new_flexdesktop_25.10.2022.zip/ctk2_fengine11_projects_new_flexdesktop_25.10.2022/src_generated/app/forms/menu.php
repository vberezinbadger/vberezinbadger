<?php
namespace app\forms;

use std, gui, framework, app;


class menu extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->alwaysOnTop = true;
        $this->x = 0;
        $this->y = 32;
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->rect7->show();

        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->rect7->hide();

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->form('menu')->hide();
        $this->form('MainForm')->rectAlt->hide();
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        $this->form('menu')->hide();
        $this->form('MainForm')->rectAlt->hide();
        $this->form('window')->show();
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->form('menu')->hide();
        $this->form('MainForm')->rectAlt->hide();
        $this->form('window')->show();
    }

    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
        $this->rect6->strokeWidth = 1;
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
        $this->rect6->strokeWidth = 0;
    }

    /**
     * @event buttonAlt.mouseDown-Left 
     */
    function doButtonAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->rect6->strokeWidth = 2;
    }

    /**
     * @event buttonAlt.mouseUp-Left 
     */
    function doButtonAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->rect6->strokeWidth = 1;
    }

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        $this->form('menu')->hide();
        $this->form('MainForm')->rectAlt->hide();
        $this->form('exitWindow')->show();
    }

}
