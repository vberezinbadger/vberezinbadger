<?php
namespace app\forms;

use std, gui, framework, app;


class window extends AbstractForm
{
    /**
     * @event image6.click-Left 
     */
    function doImage6ClickLeft(UXMouseEvent $e = null)
    {
        $this->form('window')->hide();
    }

}
