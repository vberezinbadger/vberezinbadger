<?php
namespace app\forms;

use std, gui, framework, app;


class exitWindow extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->alwaysOnTop = true;
        $this->x = 0;
        $this->y = 32;
        waitAsync(5300, function () use ($e, $event) {
            app()->shutdown();
        });
    }

}
