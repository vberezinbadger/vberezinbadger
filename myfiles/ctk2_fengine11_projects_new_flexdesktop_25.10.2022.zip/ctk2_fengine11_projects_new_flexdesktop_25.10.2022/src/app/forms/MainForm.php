<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\UXScreen;


class MainForm extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->x = 0;
        $this->y = 0;
        $this->alwaysOnTop = true;
    }

    /**
     * @event label.click-Left 
     */
    function doLabelClickLeft(UXMouseEvent $e = null)
    {    
        $this->form('menu')->show();
    }

    /**
     * @event label7.mouseDown-Left 
     */
    function doLabel7MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->label4->text = "onWindowBlinkFX_enabled: true";
        
        $this->label5->text = "onMouseAttached_status: 0x01";
    }

    /**
     * @event label7.mouseUp-Left 
     */
    function doLabel7MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->label4->text = "onWindowBlinkFX_enabled: false";
        
        $this->label5->text = "onMouseAttached_status: 0x00";
    }

    /**
     * @event image6.click-Left 
     */
    function doImage6ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

}
