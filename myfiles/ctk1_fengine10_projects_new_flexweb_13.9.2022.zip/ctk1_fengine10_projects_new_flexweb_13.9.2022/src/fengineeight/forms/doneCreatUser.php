<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class doneCreatUser extends AbstractForm
{


    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('doneCreatUser');
    }


}
