<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class ware extends AbstractForm
{

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        
    }



    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.mouseEnter 
     */
    function doCircle10MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.mouseExit 
     */
    function doCircle10MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {    
        
    }










}
