<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class speak2 extends AbstractForm
{

}