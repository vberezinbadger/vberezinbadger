<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class newCli extends AbstractForm
{

    /**
     * @event edit.globalKeyUp-Enter 
     */
    function doEditGlobalKeyUpEnter(UXKeyEvent $e = null)
    {    
        $command = $this->edit->text;
        
        switch($command) {
            
            case "clear":
                    $this->label->text = "Cleared!";
                    $this->edit->text = "";
                    break;
            
            case "about":
                    $this->label->text .= "\n\n~: about";
                    $this->label->text .= "\nFLEXcli Module Mesh Creator Test, v0.1_dev";
                    $this->edit->text = "";
                    break;
                    
            case "open hterm":
                    $this->label->text .= "\n\n~: open hterm";
                    $this->label->text .= "\nLoading application module: Hentai Terminal";
                    $this->label->text .= "\nDevelopers: Kolibra Studios, VBerezin, Hentai Group.";
                    $this->label->text .= "\nVersion: 2.0.045_dev.";
                    $this->edit->text = "";
                    app()->showForm('hterm');
                    break;
                    
            case "close hterm":
                    $this->label->text .= "\n\n~: close hterm";
                    $this->label->text .= "\nClosing application module: Hentai Terminal";
                    $this->edit->text = "";
                    app()->hideForm('hterm');
                    break;                 
            
            default:
                    $this->label->text .= "\n\n~: ". $command ."";
                    $this->label->text .= "\n[CHECK] ❯ ". $command .": not found.";
                    $this->edit->text = "";
        }         
    }

    
}
