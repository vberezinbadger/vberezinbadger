<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class createFolder extends AbstractForm
{

    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $e = null)
    {    
        if (File::of('workspace')->isDirectory()) {
            fs::makeDir('workspace/data/' . $this->edit->text . '');
            app()->hideForm('createFolder');
            $this->label6->visible = false;
            waitAsync(200, function () use ($e, $event) {
                $this->edit->text = '';
            });
        } else {
            $this->label6->visible = true;
        }
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('createFolder');
        $this->edit->text = '';
        $this->label6->visible = false;
    }

}
