<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use php\time\Time;


class main extends AbstractForm
{

    $version = "2.0.010";
    
    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
        $this->log->text .= "\nВыход из Hentai Terminal, пожалуйста подождите...";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: exit.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: unloading forms...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: unloading bootstrap...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exiting terminal session...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[SESSION]: user session stopped!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[HBASH]: exiting modules...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: saving logs... done!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exited!\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting FLEXwindow...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Saving loader logs...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Stopping plugins and modules...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    waitAsync(700, function () use ($e, $event) {
                        $this->log->text .= "\nСохранение записи состояния работы в лог-файл терминала (termLog.txt)...";
                        waitAsync(700, function () use ($e, $event) {
                            $this->log->text .= "\nОстановка модулей...";
                            waitAsync(800, function () use ($e, $event) {
                                $this->log->text .= "\nОстановка работы Hentai Bash Reborn (Anaconda Shell)...";
                                waitAsync(560, function () use ($e, $event) {
                                    $this->log->text .= "\nВыход из терминальной среды...";
                                    waitAsync(1200, function () use ($e, $event) {
                                        app()->shutdown();
                                    });});});});});
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {    
        
    }










    
    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        file_put_contents('termLog.txt', "\nStartup time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "Hentai Terminal Reborn, v2.0.010_dev.\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "Kolibra Studios 2022. All rights reserved.\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM]: loading cmdCommand Modules list...\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: termForm loading...\r\n", FILE_APPEND);
    }
    
    /**
     * @event show
     */
    function doShow(UXWindowEvent $e = null)
    {    
        file_put_contents('termLog.txt', "[TERM]: cmdStrokeModule started!\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: termForm loaded!\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: UI Elements loaded!\r\n", FILE_APPEND);
        
        # LED: User Status
        
        $this->userStatus->fillColor = "#50aa5e";
        $this->form('usrStatus')->username->text = $this->form('loginForm')->edit->text;
        
        # LED: checkEthernet
        
        $ethernetEnabled = file_get_contents('http://ya.ru') !== false;
        
        if ($ethernetEnabled) {
            $this->netStatus->fillColor = "#50aa5e";
        } else {
            $this->netStatus->fillColor = "#cca433";
        }  
        
        # logs folder Check
        
        if (File::of('logs')->isDirectory()) {
            file_put_contents('termLog.txt', "[TERM] > [LOGMGR]: logs catalog ready!\r\n", FILE_APPEND);
        } else {
            fs::makeDir('logs');
            fs::makeDir('logs/crash');
        }
        
        # noWindowCirlceConfig Check
        
        if (File::of('config/noCircleWindow.true')->isFile()) {
            $this->rect8->arcWidth = 0;
            $this->rect8->arcHeight = 0;
        
            $this->rectAlt->arcWidth = 0;
            $this->rectAlt->arcHeight = 0;
        
            $this->rect->arcWidth = 0;
            $this->rect->arcHeight = 0;
            
            $this->panel5->borderRadius = 0;
            
            $this->rect38->arcWidth = 0;
            $this->rect38->arcHeight = 0;
        } else {
            $this->rect8->arcWidth = 18;
            $this->rect8->arcHeight = 18;
        
            $this->rectAlt->arcWidth = 16;
            $this->rectAlt->arcHeight = 16;
        
            $this->rect->arcWidth = 16;
            $this->rect->arcHeight = 16;
            
            $this->panel5->borderRadius = 8;
            
            $this->rect38->arcWidth = 16;
            $this->rect38->arcHeight = 16;
        }    
            
        # newMenuCTKConfig Check
            
        if (File::of('config/newMenuCTK.true')->isFile()) {
            $this->rect5->visible = true;
            $this->imageAlt->visible = true;
            $this->button->visible = true;
            $this->label->x = 104;
        } else {
            $this->rect5->visible = false;
            $this->imageAlt->visible = false;
            $this->button->visible = false;
            $this->label->x = 66;
        }
    }











    /**
     * @event rect5.click-Left 
     */
    function doRect5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event image6.click 
     */
    function doImage6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect4.click 
     */
    function doRect4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label.click 
     */
    function doLabelClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect3.click 
     */
    function doRect3Click(UXMouseEvent $e = null)
    {    
        
    }




    /**
     * @event circle4.click 
     */
    function doCircle4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click 
     */
    function doCircle8Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image3.click 
     */
    function doImage3Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circleAlt.click 
     */
    function doCircleAltClick(UXMouseEvent $e = null)
    {    
        
    }


















































}
