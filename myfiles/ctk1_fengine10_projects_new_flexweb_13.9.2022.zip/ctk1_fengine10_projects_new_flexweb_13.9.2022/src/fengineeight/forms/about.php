<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class about extends AbstractForm
{

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect4.click 
     */
    function doRect4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect3.click 
     */
    function doRect3Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image6.click 
     */
    function doImage6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label.click 
     */
    function doLabelClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('about');
    }

    /**
     * @event rect9.click 
     */
    function doRect9Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label3.click-Left 
     */
    function doLabel3ClickLeft(UXMouseEvent $e = null)
    {    
        $this->rect6->visible = false;
        $this->labelAlt->textColor = '#333333';
        $this->rect7->visible = true;
        $this->label3->textColor = '#ffffff';
        $this->panel->visible = false;
        $this->panelAlt->visible = true;
    }

    /**
     * @event labelAlt.click-Left 
     */
    function doLabelAltClickLeft(UXMouseEvent $e = null)
    {    
        $this->rect6->visible = true;
        $this->labelAlt->textColor = '#ffffff';
        $this->rect7->visible = false;
        $this->label3->textColor = '#333333';
        $this->panel->visible = true;
        $this->panelAlt->visible = false;
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        # noWindowCirlceConfig Check
        
        if (File::of('config/noCircleWindow.true')->isFile()) {
            $this->rect8->arcWidth = 0;
            $this->rect8->arcHeight = 0;
        
            $this->rectAlt->arcWidth = 0;
            $this->rectAlt->arcHeight = 0;
        
            $this->rect->arcWidth = 0;
            $this->rect->arcHeight = 0;
        } else {
            $this->rect8->arcWidth = 18;
            $this->rect8->arcHeight = 18;
        
            $this->rectAlt->arcWidth = 16;
            $this->rectAlt->arcHeight = 16;
        
            $this->rect->arcWidth = 16;
            $this->rect->arcHeight = 16;
        }
    }



}
