<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class crashWindow extends AbstractForm
{


    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event label7.click-Left 
     */
    function doLabel7ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event label8.click-Left 
     */
    function doLabel8ClickLeft(UXMouseEvent $e = null)
    {
        browse('https://vk.com/im?sel=-209421816');
    }

}
