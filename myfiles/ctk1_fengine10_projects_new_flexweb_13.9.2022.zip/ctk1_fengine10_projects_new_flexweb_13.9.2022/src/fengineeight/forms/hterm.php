<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use php\time\Time;


class hterm extends AbstractForm
{

    $version = "2.0.010";
    
    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
        $this->log->text .= "\nВыход из Hentai Terminal, пожалуйста подождите...";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: exit.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: unloading forms...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: unloading bootstrap...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exiting terminal session...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[SESSION]: user session stopped!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[HBASH]: exiting modules...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: saving logs... done!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exited!\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting FLEXwindow...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Saving loader logs...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Stopping plugins and modules...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    waitAsync(700, function () use ($e, $event) {
                        $this->log->text .= "\nСохранение записи состояния работы в лог-файл терминала (termLog.txt)...";
                        waitAsync(700, function () use ($e, $event) {
                            $this->log->text .= "\nОстановка модулей...";
                            waitAsync(800, function () use ($e, $event) {
                                $this->log->text .= "\nОстановка работы Hentai Bash Reborn (Anaconda Shell)...";
                                waitAsync(560, function () use ($e, $event) {
                                    $this->log->text .= "\nВыход из терминальной среды...";
                                    waitAsync(1200, function () use ($e, $event) {
                                        app()->shutdown();
                                    });});});});});
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event edit.keyUp-Enter 
     */
    function doEditKeyUpEnter(UXKeyEvent $e = null)
    {    
        $command = $this->edit->text;
        
        switch($command) {
            
            case "theme":
                    $this->log->text .= "\n~: theme";
                    $this->log->text .= "\nTheme Manager, версия: 1.0. \nAleksandr Prudkov, Kolibra Studios. Все права защищены. \nЧтобы узнать команды, введите: theme -help \n";
                    $this->edit->text = "";
                    break;
            
            case "videoplayer":
                    $this->log->text .= "\n~: videoplayer";
                    $this->log->text .= "\nЗапуск Видеоплеера... \n";
                    $this->edit->text = "";
                    app()->showForm('videoplayer');
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: videoplayer.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: loading module: videoModule...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: opening form: videoplayer...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: loaded!\r\n", FILE_APPEND);
                    break;
            
            case "pkg":
                    $this->log->text .= "\n~: pkg";
                    $this->log->text .= "\nPackage Manager, версия 1.0.";
                    $this->log->text .= "\nЧтобы узнать, как пользоваться и узнать об аргументах Package Manager, введите команду: pkg help. \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: pkg.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: invalid argument!\r\n", FILE_APPEND);
                    break;
                    
            case "pkg help":
                    $this->log->text .= "\n~: pkg help";
                    $this->log->text .= "\nPackage Manager, версия 1.0.";
                    $this->log->text .= "\nИспользование pkg: \n- pkg install [pkg_name]: установить пакет \n- pkg delete [pkg_name]: удалить пакет \n- pkg list: лист всех пакетов с сервера Hentai Packages \n- pkg installed: лист установленных пакетов \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: pkg -help.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: package manager help tool showed!\r\n", FILE_APPEND);
                    break;
                    
            case "pkg list":
                    $pkglist = file_get_contents('https://kolibra.site/flex/hterm/pkgmgr/pkglist.txt');
                    $this->log->text .= "\n~: pkg list";
                    $this->log->text .= "\nPackage Manager, версия 1.0.";
                    $this->log->text .= "\nПакеты, которые можно установить: \n";
                    $this->log->text .= "" . $pkglist . " \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: pkg -help.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: package manager help tool showed!\r\n", FILE_APPEND);
                    break;                
            
            case "clear":
                    $this->log->text = "Очистка консоли выполнена! \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: clear. \n";
                    echo "\n[TERM]: Cleared! \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: clear.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: output cleared!\r\n", FILE_APPEND);
                    break;
                    
            case "create -crashlog":
                    $this->log->text .= "\n~: create -crashlog";
                    $this->log->text .= "\nЛог-файл для текущей даты создан! \n";
                    $this->edit->text = "";
                    file_put_contents('logs/crash/crashlog-' . Time::now()->toString('dd.MM.yyyy') . '.txt', "[" . Time::now()->toString('HH:mm:ss') . "] [TERM]: called cmdCommand: task version -check.\r\n", FILE_APPEND);
                    break;
                    
            case "kill":
                    $this->enabled = false;
                    waitAsync(3400, function () use ($e, $event) {
                    app()->hideForm('hterm');
                    app()->showForm('crashWindow');
                    waitAsync(700, function () use ($e, $event) {
                        file_put_contents('logs/crash/crashlog-' . Time::now()->toString('dd.MM.yyyy') . '.txt', "[" . Time::now()->toString('HH:mm:ss') . "] [TERM]: called cmdCommand: kill.\r\n", FILE_APPEND);
                        waitAsync(700, function () use ($e, $event) {
                            file_put_contents('logs/crash/crashlog-' . Time::now()->toString('dd.MM.yyyy') . '.txt', "[" . Time::now()->toString('HH:mm:ss') . "] [FLEXengine/WARN]: stopping HTerminal session... \r\n", FILE_APPEND);
                            waitAsync(800, function () use ($e, $event) {
                                file_put_contents('logs/crash/crashlog-' . Time::now()->toString('dd.MM.yyyy') . '.txt', "[" . Time::now()->toString('HH:mm:ss') . "] [FLEXengine/CRITICAL]: stopping FLEXengine Core... \r\n", FILE_APPEND);
                                waitAsync(560, function () use ($e, $event) {
                                    file_put_contents('logs/crash/crashlog-' . Time::now()->toString('dd.MM.yyyy') . '.txt', "[" . Time::now()->toString('HH:mm:ss') . "] [FLEXengine/CRITICAL]: stopping CTK and closing CLI-session... \r\n", FILE_APPEND);
                                    waitAsync(1200, function () use ($e, $event) {
                                        file_put_contents('logs/crash/crashlog-' . Time::now()->toString('dd.MM.yyyy') . '.txt', "[" . Time::now()->toString('HH:mm:ss') . "] [Debug/INFO]: opening: Error Reporting Window... \r\n", FILE_APPEND);
                                    });});});});});});
                    break;          
                    
            case "check net":
                    $this->log->text .= "\n~: check net";
                    $this->edit->text = "";
                    $ethernetEnabled = file_get_contents('http://ya.ru') !== false;
        
                    if ($ethernetEnabled) {
                        $this->netStatus->fillColor = "#50aa5e";
                        $this->log->text .= "\nИнтернет-подключение имеется. Терминал подключен к серверу HentaiNET. Вы можете полноценно пользоваться терминалом. \n";
                    } else {
                        $this->netStatus->fillColor = "#cca433";
                        $this->log->text .= "\nИнтернет-подключение отсутствует. Терминал не подключен к серверу HentaiNET, но вы можете пользоваться терминалом, хоть некоторые функции работать и не будут. \n";
                    }  
                    break;
            
            case "create -folder":
                    $this->log->text .= "\n~: create -folder";
                    $this->log->text .= "\nВызвана форма для создания папки! \n";
                    $this->edit->text = "";
                    app()->showFormAndWait('createFolder');
                    break;
                    
            case "panel":
                    $this->log->text .= "\n~: panel";
                    $this->log->text .= "\nОткрыта XRoss Panel! \n";
                    $this->edit->text = "";
                    app()->showForm('widgetPanel');
                    break;        
                    
            case "reload":
                    app()->hideForm('hterm');
                    wait(3200);
                    app()->showForm('hterm');
                    $this->log->text = "Быстрая перезагрузка Hentai Terminal успешно выполнена! \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: reload. \n";
                    echo "\n[TERM]: Reloaded! \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: reload.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: reloaded!\r\n", FILE_APPEND);
                    break;        
            
            case "about":
                    $this->log->text .= "\n~: about";
                    $this->log->text .= "\nHentai Terminal Developer Preview \nВерсия: 2.0.010. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: about. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: output version: 2.0.010.\r\n", FILE_APPEND);
                    break;
                    
            case "about -core":
                    $this->log->text .= "\n~: about -core";
                    $this->log->text .= "\nИнформация о ядре. \nЯдро: Anaconda Shell (на базе Hentai Bash и OctopusSH). \nВерсия ядра: 2.0.010_dev. \nТерминал: hterm-windows. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand: about -core. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about -core.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "Anaconda Shell, v2.0.010_dev.\r\n", FILE_APPEND);
                    break;
                    
            case "about -gui":
                    $this->log->text .= "\n~: about -gui";
                    $this->log->text .= "\nМеню о программе в графическом режиме. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand with args: about -gui. \n";
                    app()->showFormAndWait('about');
                    echo "\n[CTK Debug]: loaded formInfo: about.form. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about -core.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: loaded formInfo: about.form.\r\n", FILE_APPEND);
                    break;
                    
            case "exit":
                    $this->log->text .= "\n~: exit";
                    $this->log->text .= "\nВыход из Hentai Terminal, пожалуйста подождите...";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: exit.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: unloading forms...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: unloading bootstrap...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exiting terminal session...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[SESSION]: user session stopped!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[HBASH]: exiting modules...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: saving logs... done!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exited!\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting FLEXwindow...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Saving loader logs...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Stopping plugins and modules...\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exiting...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    file_put_contents('loaderLog.txt', "[LOADER] - Exit time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
                    waitAsync(700, function () use ($e, $event) {
                        $this->log->text .= "\nСохранение записи состояния работы в лог-файл терминала (termLog.txt)...";
                        waitAsync(700, function () use ($e, $event) {
                            $this->log->text .= "\nОстановка модулей...";
                            waitAsync(800, function () use ($e, $event) {
                                $this->log->text .= "\nОстановка работы Hentai Bash Reborn (Anaconda Shell)...";
                                waitAsync(560, function () use ($e, $event) {
                                    $this->log->text .= "\nВыход из терминальной среды...";
                                    waitAsync(1200, function () use ($e, $event) {
                                        app()->shutdown();
                                    });});});});});
                    break;
                    
            case "logout":
                    $this->log->text .= "\n~: logout";
                    $this->log->text .= "\nВыход из Hentai Terminal, пожалуйста подождите...";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: logout.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: closing session...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: unloading bootstrap...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exiting terminal session...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[SESSION]: user session stopped!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[HBASH]: exiting modules...\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: saving logs... done!\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: exited!\r\n", FILE_APPEND);
                    $this->log->text .= "\nЗавершение работы терминальной сессии...";
                        waitAsync(560, function () use ($e, $event) {
                        $this->log->text .= "\nВыход из учётной записи...";
                            waitAsync(1200, function () use ($e, $event) {
                                $this->loadForm('loginForm');
                                $this->form('loginForm')->edit->text = "";
                                $this->form('loginForm')->passwordField->text = "";
                                $this->form('loginForm')->panelAlt->visible = false;
                                $this->form('loginForm')->panel->visible = true;
                                $this->form('loginForm')->label9->visible = false;
                                $this->form('loginForm')->label5->visible = false;
                                $this->log->text = "Hentai Terminal Developer Preview \nВерсия: 2.0.010 \n \nKolibra Studios, 2022. Все права защищены. \n";
                    });});
                    break;        
                    
            case "time":
                    $this->log->text .= "\n~: time";
                    $this->log->text .= "\nТекущее время: " . Time::now()->toString('HH:mm') . ". \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: time.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: time showed!\r\n", FILE_APPEND);
                    break;
                    
            case "date":
                    $this->log->text .= "\n~: date";
                    $this->log->text .= "\nТекущая дата: " . Time::now()->toString('dd.MM.yyyy') . ". \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: date.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: date showed!\r\n", FILE_APPEND);
                    break;
                    
            case "version -check":
                    $version = "2.0.010";
                    $sversion = file_get_contents('https://kolibra.site/flex/hterm/version.txt');
                    $changelog = file_get_contents('https://kolibra.site/flex/hterm/changelog/lastchangelog.txt');
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: task version -check.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[UPDATE-MANAGER]: Checking updates...\r\n", FILE_APPEND);
                    
                    if($version == $sversion) {
                        $this->log->text .= "\n~: version -check";
                        $this->log->text .= "\nВерсия сервера: " . $sversion . "";
                        $this->log->text .= "\nВерсия клиента с версией сервера совпадает. Поиск и установка обновлений не требуется. \n";
                        file_put_contents('termLog.txt', "[UPDATE-MANAGER]: No have updates!\r\n", FILE_APPEND);
                        $this->edit->text = "";
                    } else {
                        $this->log->text .= "\n~: version -check";
                        $this->log->text .= "\nВерсия сервера: " . $sversion . "";
                        $this->log->text .= "\nВерсия клиента устарела. Чтобы получить доступ к новейшим функциям, необходимо обновиться до свежей версии Hentai Terminal. \n";
                        file_put_contents('termLog.txt', "[UPDATE-MANAGER]: Update found > version: " . $sversion . ". Upgrade to get stability, a high level of performance and functionality!\r\n", FILE_APPEND);
                        $this->edit->text = "";
                        $this->textArea->text = $changelog;
                        $this->label25->text = $sversion;
                        $this->panel4->show();
                        waitAsync(300, function () use ($e, $event) {
                        Animation::fadeIn($this->panel4, 130);
                        });
                    }   
                    break;
                    
            case "version":
                    $this->log->text .= "\n~: version";
                    $this->log->text .= "\n2.0.010 \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: version.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: version: 2.0.010.\r\n", FILE_APPEND);
                    break;
                    
            case "config":
                    $this->log->text .= "\n~: config";
                    $this->log->text .= "\nConfig Manager, версия: 1.0 \nИспользование: \n- config [параметр конфига] [true|false]: включение или отключение опции \n- config help: руководство до использованию Config Manager \n- config list: все параметры, доступные для данного приложения \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: config.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: Config Manager, version 1.0.\r\n", FILE_APPEND);
                    break;
                    
            case "config list":
                    $this->log->text .= "\n~: config list";
                    $this->log->text .= "\nВсе параметры для Hentai Terminal: \n- noCircleWindow: управление закруглениями окон и фреймов \n- newMenuTest: управление показом меню \n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: config list.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM]: config list showed!\r\n", FILE_APPEND);
                    break;          
            
            case "config noCircleWindow -true":
                    $this->log->text .= "\n~: config noCircleWindow -true";
                    $this->log->text .= "\nОтключение загругления окон и фреймов: включено.\n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: config noCircleWindow -true.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[CFGMGR]: noCircleWindow > true.\r\n", FILE_APPEND);
                    File::of('config/noCircleWindow.true')->createNewFile();
                    if (File::of('config/noCircleWindow.true')->isFile()) {
                        $this->rect8->arcWidth = 0;
                        $this->rect8->arcHeight = 0;
        
                        $this->rectAlt->arcWidth = 0;
                        $this->rectAlt->arcHeight = 0;
        
                        $this->rect->arcWidth = 0;
                        $this->rect->arcHeight = 0;
            
                        $this->panel5->borderRadius = 0;
            
                        $this->rect38->arcWidth = 0;
                        $this->rect38->arcHeight = 0;
                    }
                    break;
                    
            case "config noCircleWindow -false":
                    $this->log->text .= "\n~: config noCircleWindow -false";
                    $this->log->text .= "\nОтключение загругления окон и фреймов: отключено.\n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: config noCircleWindow -false.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[CFGMGR]: noCircleWindow > false.\r\n", FILE_APPEND);
                    unlink('config/noCircleWindow.true');
                    if (!File::of('config/noCircleWindow.true')->isFile()) {
                        $this->rect8->arcWidth = 18;
                        $this->rect8->arcHeight = 18;
        
                        $this->rectAlt->arcWidth = 16;
                        $this->rectAlt->arcHeight = 16;
        
                        $this->rect->arcWidth = 16;
                        $this->rect->arcHeight = 16;
            
                        $this->panel5->borderRadius = 8;
            
                        $this->rect38->arcWidth = 16;
                        $this->rect38->arcHeight = 16;
                    }
                    break;
                    
            case "config newMenuTest -true":
                    $this->log->text .= "\n~: config newMenuTest -true";
                    $this->log->text .= "\nНовое меню CTK для Hentai Terminal: включено.\n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: config newMenuTest -true.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[CFGMGR]: newMenuTest > true\r\n", FILE_APPEND);
                    File::of('config/newMenuCTK.true')->createNewFile();
                    if (File::of('config/newMenuCTK.true')->isFile()) {
                        $this->rect5->visible = true;
                        $this->imageAlt->visible = true;
                        $this->button->visible = true;
                        $this->label->x = 104;
                    }
                    break;
                    
            case "config newMenuTest -false":
                    $this->log->text .= "\n~: config newMenuTest -false";
                    $this->log->text .= "\nНовое меню CTK для Hentai Terminal: отключено.\n";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: config newMenuTest -false.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[CFGMGR]: newMenuTest > false\r\n", FILE_APPEND);
                    unlink('config/newMenuCTK.true');
                    if (!File::of('config/newMenuCTK.true')->isFile()) {
                        $this->rect5->visible = false;
                        $this->imageAlt->visible = false;
                        $this->button->visible = false;
                        $this->label->x = 66;
                    }
                    break;
                    
            case "usermgr":
                    $this->log->text .= "\n~: usermgr";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: usermgr.\r\n", FILE_APPEND);
                    if (File::of('workspace/users')->isDirectory()){
                        $this->log->text .= "\nUser Manager готов к работе! \nЧтобы знать, как им пользоваться, введите: usermgr -help \n";
                    } else {
                        $this->log->text .= "\nUser Manager не готов к работе и не может быть использован! \nДля работы необходимо инициализировать Workspace (команда: workspace -create)! \n";
                    }
                    break;      
                    
            case "usermgr -add":
                    $this->log->text .= "\n~: usermgr -add";
                    $this->edit->text = "";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: usermgr add.\r\n", FILE_APPEND);
                    if (File::of('workspace/users')->isDirectory()){
                        $this->log->text .= "\nWorkspace User Manager: запуск службы UserAdd... \n";
                        app()->showForm('createUser');
                    } else {
                        $this->log->text .= "\nUser Manager не готов к работе и не может быть использован! \nДля работы необходимо инициализировать Workspace (команда: workspace -create)! \n";
                    }
                    break;            
                    
            case "workspace -create":
                    $this->log->text .= "\n~: workspace -create";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    if (File::of('workspace')->isDirectory()) {
                        $this->log->text .= "\nОкружение Workspace уже настроено и работает! Действие не требуется! \n";
                        $this->edit->enabled = true;
                        $this->edit->promptText = "Ввод команды";
                        file_put_contents('termLog.txt', "[WORKSPACE]: no action required!\r\n", FILE_APPEND);
                    } else {
                        fs::makeDir('workspace');
                        fs::makeDir('workspace/users');
                        fs::makeDir('workspace/data');
                        fs::makeDir('workspace/logs');
                        fs::makeDir('workspace/users/root');
                        File::of('workspace/users/root/usermgr.username')->createNewFile();
                        file_put_contents('workspace/users/root/usermgr.username', "root");
                        File::of('workspace/users/root/usermgr.password')->createNewFile();
                        file_put_contents('workspace/users/root/usermgr.password', "root");
                        fs::makeDir('workspace/packages');
                        fs::makeDir('workspace/packages/stock');
                        fs::makeDir('workspace/packages/logs');
                        fs::makeDir('workspace/hbash');
                        fs::makeDir('workspace/hbash/logs');
                        fs::makeDir('workspace/hbash/core/jinx-x64');
                        fs::makeDir('workspace/hbash/core/jinx-x64/logs');
                        fs::makeDir('workspace/hbash/core/jinx-x86');
                        fs::makeDir('workspace/hbash/core/jinx-x86/logs');
                        fs::makeDir('workspace/hbash/core/jinx-arm64');
                        fs::makeDir('workspace/hbash/core/jinx-arm64/logs');
                        file_put_contents('workspace/hbash/core/jinx-x64/logs/log.txt', "[ i ] - JINX Core successfully initialized module: Workspace!\r\n", FILE_APPEND);
                        file_put_contents('workspace/hbash/core/jinx-x86/logs/log.txt', "[ i ] - JINX Core successfully initialized module: Workspace!\r\n", FILE_APPEND);
                        file_put_contents('workspace/hbash/core/jinx-arm64/logs/log.txt', "[ i ] - JINX Core successfully initialized module: Workspace!\r\n", FILE_APPEND);
                        file_put_contents('workspace/hbash/logs/log.txt', "[ i ] - Hentai Bash -> Workspace: metamorphosis is created!\r\n", FILE_APPEND);
                        file_put_contents('workspace/logs/log.txt', "[ i ] - Workspace created! Version: 1.0.\r\n", FILE_APPEND);
                        file_put_contents('workspace/packages/logs/log.txt', "[ i ] - Done! Now all packages downloaded by you on behalf of root will be located here and will be accessible using special launch commands!\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[WORKSPACE]: Hello, world!\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: called cmdCommand: workspace -create.\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: creating workspace...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM] > [INIT]: init usermgr...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: creating catalogs...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[SESSION]: reload session in: root\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[HBASH]: import module: workspace-hbash-2.0.010_dev.pkg... (100%) Done!\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: saving workspace settings...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: done! Workspace Module working!\r\n", FILE_APPEND);
                        waitAsync(700, function () use ($e, $event) {
                            $this->log->text .= "\nСоздание Workspace контейнера...";
                                waitAsync(700, function () use ($e, $event) {
                                    $this->log->text .= "\nЗагрузка модулей для: Workspace...";
                                        waitAsync(800, function () use ($e, $event) {
                                            $this->log->text .= "\nЗапуск модулей...";
                                                waitAsync(560, function () use ($e, $event) {
                                                    $this->log->text .= "\nИнициализация Workspace...";
                                                        waitAsync(1200, function () use ($e, $event) {
                                                            $this->log->text .= "\nГотово! Workspace готов к работе! \n";
                                                                waitAsync(200, function () use ($e, $event) {
                                                                    $this->edit->promptText = "Ввод команды";
                                                                        waitAsync(200, function () use ($e, $event) {
                                                                            $this->edit->enabled = true;
                        });});});});});});});
                    }
                    break;
                    
            case "workspace -delete":
                    $this->log->text .= "\n~: workspace -delete";
                    $this->edit->text = "";
                    $this->edit->enabled = false;
                    $this->edit->promptText = "Ввод команд недоступен";
                    if (!File::of('workspace')->isDirectory()) {
                        $this->log->text .= "\nОкружение Workspace не включено и не настроено! Действие не требуется! \n";
                        $this->edit->enabled = true;
                        $this->edit->promptText = "Ввод команды";
                        file_put_contents('termLog.txt', "[TERM]: no action required!\r\n", FILE_APPEND);
                    } else {
                        $workspacePath = 'workspace';
                        fs::clean($workspacePath);
                        fs::delete($workspacePath);
                        file_put_contents('termLog.txt', "[WORKSPACE]: Goodbye!\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: called cmdCommand: workspace -delete.\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: disable workspace...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM] > [INIT]: shutdown usermgr...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: deleting catalogs...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[SESSION]: reload session in: bash\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[HBASH]: unloading modules..\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: deleting workspace settings...\r\n", FILE_APPEND);
                        file_put_contents('termLog.txt', "[TERM]: done! Workspace Module disabled! Reload Hentai Terminal (command: reload)\r\n", FILE_APPEND);
                        waitAsync(700, function () use ($e, $event) {
                            $this->log->text .= "\nУдаление Workspace контейнера...";
                                waitAsync(700, function () use ($e, $event) {
                                    $this->log->text .= "\nУдаление модулей для: Workspace...";
                                        waitAsync(800, function () use ($e, $event) {
                                            $this->log->text .= "\nОстановка модулей...";
                                                waitAsync(560, function () use ($e, $event) {
                                                    $this->log->text .= "\nЗавершение работы Workspace...";
                                                        waitAsync(1200, function () use ($e, $event) {
                                                            $this->log->text .= "\nГотово! Workspace успешно отключен! \n";
                                                                waitAsync(200, function () use ($e, $event) {
                                                                    $this->edit->promptText = "Ввод команды";
                                                                        waitAsync(200, function () use ($e, $event) {
                                                                            $this->edit->enabled = true;
                        });});});});});});});
                    }
                    break;        
                    
            case "workspace -status":
                    $this->log->text .= "\n~: workspace -status";
                    $this->edit->text = "";
                    if (File::of('workspace')->isDirectory()) {
                        $this->log->text .= "\nОкружение Workspace уже настроено и работает! Действие не требуется! \n";
                        file_put_contents('termLog.txt', "[WORKSPACE]: status: working.\r\n", FILE_APPEND);
                    } else {
                        $this->log->text .= "\nОкружение Workspace не включено и не настроено! \nЧтобы включить и пользоваться: \n- workspace -create \n";
                        file_put_contents('termLog.txt', "[WORKSPACE]: status: not working, enable: workspace -create.\r\n", FILE_APPEND);
                    }
                    break;        
                    
            case "hello":
                    $this->log->text .= "\n~: hello";
                    $this->log->text .= "\nHello, world! \n";
                    $this->edit->text = "";
                    break;
                    
            default:
                    $this->log->text .= "\n~: ". $command ."";
                    $this->log->text .= "\nНеверная команда. Возможно, в команде опечатка, или синтаксическая ошибка. \n";
                    $this->edit->text = "";
                    echo "\n[ERROR]: called defaultCmdMessage: noFoundCmd. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: ". $command ." (notFound).\r\n", FILE_APPEND);
                    break;               
        }
    }





    
    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        file_put_contents('termLog.txt', "\nStartup time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "Hentai Terminal Reborn, v2.0.010_dev.\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "Kolibra Studios 2022. All rights reserved.\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM]: loading cmdCommand Modules list...\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: termForm loading...\r\n", FILE_APPEND);
    }
    
    /**
     * @event show
     */
    function doShow(UXWindowEvent $e = null)
    {    
        file_put_contents('termLog.txt', "[TERM]: cmdStrokeModule started!\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: termForm loaded!\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: UI Elements loaded!\r\n", FILE_APPEND);
        
        # LED: User Status
        
        $this->userStatus->fillColor = "#50aa5e";
        $this->form('usrStatus')->username->text = $this->form('loginForm')->edit->text;
        
        # LED: checkEthernet
        
        $ethernetEnabled = file_get_contents('http://ya.ru') !== false;
        
        if ($ethernetEnabled) {
            $this->netStatus->fillColor = "#50aa5e";
        } else {
            $this->netStatus->fillColor = "#cca433";
        }  
        
        # logs folder Check
        
        if (File::of('logs')->isDirectory()) {
            file_put_contents('termLog.txt', "[TERM] > [LOGMGR]: logs catalog ready!\r\n", FILE_APPEND);
        } else {
            fs::makeDir('logs');
            fs::makeDir('logs/crash');
        }
        
        # noWindowCirlceConfig Check
        
        if (File::of('config/noCircleWindow.true')->isFile()) {
            $this->rect8->arcWidth = 0;
            $this->rect8->arcHeight = 0;
        
            $this->rectAlt->arcWidth = 0;
            $this->rectAlt->arcHeight = 0;
        
            $this->rect->arcWidth = 0;
            $this->rect->arcHeight = 0;
            
            $this->panel5->borderRadius = 0;
            
            $this->rect38->arcWidth = 0;
            $this->rect38->arcHeight = 0;
        } else {
            $this->rect8->arcWidth = 18;
            $this->rect8->arcHeight = 18;
        
            $this->rectAlt->arcWidth = 16;
            $this->rectAlt->arcHeight = 16;
        
            $this->rect->arcWidth = 16;
            $this->rect->arcHeight = 16;
            
            $this->panel5->borderRadius = 8;
            
            $this->rect38->arcWidth = 16;
            $this->rect38->arcHeight = 16;
        }    
            
        # newMenuCTKConfig Check
            
        if (File::of('config/newMenuCTK.true')->isFile()) {
            $this->rect5->visible = true;
            $this->imageAlt->visible = true;
            $this->button->visible = true;
            $this->label->x = 104;
        } else {
            $this->rect5->visible = false;
            $this->imageAlt->visible = false;
            $this->button->visible = false;
            $this->label->x = 66;
        }
    }






    /**
     * @event circle11.mouseEnter 
     */
    function doCircle11MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle11.mouseExit 
     */
    function doCircle11MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle11.click-Left 
     */
    function doCircle11ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event imageAlt.click-Left 
     */
    function doImageAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect5.click-Left 
     */
    function doRect5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event image6.click 
     */
    function doImage6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect4.click 
     */
    function doRect4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label.click 
     */
    function doLabelClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect3.click 
     */
    function doRect3Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.click 
     */
    function doLabelAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect6.click 
     */
    function doRect6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect7.click 
     */
    function doRect7Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.click 
     */
    function doCircle4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click 
     */
    function doCircle8Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image3.click 
     */
    function doImage3Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circleAlt.click 
     */
    function doCircleAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect47.click 
     */
    function doRect47Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this->buttonAlt, 130, 0.2);
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this->buttonAlt, 130, 0.0);
    }

    /**
     * @event buttonAlt.mouseDown-Left 
     */
    function doButtonAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this->buttonAlt, 130, 0.5);
    }

    /**
     * @event buttonAlt.mouseUp-Left 
     */
    function doButtonAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this->buttonAlt, 130, 0.2);
    }

    /**
     * @event button3.mouseEnter 
     */
    function doButton3MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button3, 130, 0.2);
    }

    /**
     * @event button3.mouseExit 
     */
    function doButton3MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button3, 130, 0.0);
    }

    /**
     * @event button3.mouseDown-Left 
     */
    function doButton3MouseDownLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button3, 130, 0.5);
    }

    /**
     * @event button3.mouseUp-Left 
     */
    function doButton3MouseUpLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button3, 130, 0.2);
    }

    /**
     * @event button4.mouseEnter 
     */
    function doButton4MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button4, 130, 0.2);
    }

    /**
     * @event button4.mouseExit 
     */
    function doButton4MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button4, 130, 0.0);
    }

    /**
     * @event button4.mouseDown-Left 
     */
    function doButton4MouseDownLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button4, 130, 0.5);
    }

    /**
     * @event button4.mouseUp-Left 
     */
    function doButton4MouseUpLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button4, 130, 0.2);
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        browse('https://vk.com/im?sel=-209421816');
        
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        browse('https://vk.com/kolibracorp.hterminal');
        
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        browse('https://vk.com/kolibracorp.hterminal');
        
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
    }

    /**
     * @event button5.mouseEnter 
     */
    function doButton5MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button5, 130, 0.2);
    }

    /**
     * @event button5.mouseExit 
     */
    function doButton5MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button5, 130, 0.0);
    }

    /**
     * @event button5.mouseDown-Left 
     */
    function doButton5MouseDownLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button5, 130, 0.5);
    }

    /**
     * @event button5.mouseUp-Left 
     */
    function doButton5MouseUpLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button5, 130, 0.2);
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
        
        $version = "2.0.010";
                    $sversion = file_get_contents('https://kolibra.site/flex/hterm/version.txt');
                    $changelog = file_get_contents('https://kolibra.site/flex/hterm/changelog/lastchangelog.txt');
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: task version -check.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[UPDATE-MANAGER]: Checking updates...\r\n", FILE_APPEND);
                    
                    if($version == $sversion) {
                        $this->log->text .= "\n~: version -check";
                        $this->log->text .= "\nВерсия сервера: " . $sversion . "";
                        $this->log->text .= "\nВерсия клиента с версией сервера совпадает. Поиск и установка обновлений не требуется. \n";
                        file_put_contents('termLog.txt', "[UPDATE-MANAGER]: No have updates!\r\n", FILE_APPEND);
                        $this->edit->text = "";
                    } else {
                        $this->log->text .= "\n~: version -check";
                        $this->log->text .= "\nВерсия сервера: " . $sversion . "";
                        $this->log->text .= "\nВерсия клиента устарела. Чтобы получить доступ к новейшим функциям, необходимо обновиться до свежей версии Hentai Terminal. \n";
                        file_put_contents('termLog.txt', "[UPDATE-MANAGER]: Update found > version: " . $sversion . ". Upgrade to get stability, a high level of performance and functionality!\r\n", FILE_APPEND);
                        $this->edit->text = "";
                        $this->textArea->text = $changelog;
                        $this->label25->text = $sversion;
                        $this->panel4->show();
                        waitAsync(300, function () use ($e, $event) {
                        Animation::fadeIn($this->panel4, 130);
                        });
                    }   
    }

    /**
     * @event button6.mouseEnter 
     */
    function doButton6MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button6, 130, 0.2);
    }

    /**
     * @event button6.mouseExit 
     */
    function doButton6MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button6, 130, 0.0);
    }

    /**
     * @event button6.mouseDown-Left 
     */
    function doButton6MouseDownLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button6, 130, 0.5);
    }

    /**
     * @event button6.mouseUp-Left 
     */
    function doButton6MouseUpLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button6, 130, 0.2);
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
        
        $this->log->text .= "\n~: about -gui";
                    $this->log->text .= "\nМеню о программе в графическом режиме. \n";
                    $this->edit->text = "";
                    echo "\n[TERM]: called cmdCommand with args: about -gui. \n";
                    app()->showFormAndWait('about');
                    echo "\n[CTK Debug]: loaded formInfo: about.form. \n";
                    file_put_contents('termLog.txt', "[TERM]: called cmdCommand: about -core.\r\n", FILE_APPEND);
                    file_put_contents('termLog.txt', "[TERM] > [CTK Debug]: loaded formInfo: about.form.\r\n", FILE_APPEND); 
    }

    /**
     * @event button7.mouseEnter 
     */
    function doButton7MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button7, 130, 0.2);
    }

    /**
     * @event button7.mouseExit 
     */
    function doButton7MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button7, 130, 0.0);
    }

    /**
     * @event button7.mouseDown-Left 
     */
    function doButton7MouseDownLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button7, 130, 0.5);
    }

    /**
     * @event button7.mouseUp-Left 
     */
    function doButton7MouseUpLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button7, 130, 0.2);
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {
        browse('https://github.com/hentai-team');
        
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
    }

    /**
     * @event button8.mouseEnter 
     */
    function doButton8MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button8, 130, 0.2);
    }

    /**
     * @event button8.mouseExit 
     */
    function doButton8MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button8, 130, 0.0);
    }

    /**
     * @event button8.mouseDown-Left 
     */
    function doButton8MouseDownLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button8, 130, 0.5);
    }

    /**
     * @event button8.mouseUp-Left 
     */
    function doButton8MouseUpLeft(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->button8, 130, 0.2);
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {
        browse('https://vk.com/kolibracorp.hterminal');
        
        Animation::fadeOut($this->panel5, 130);
        waitAsync(300, function () use ($e, $event) {
        $this->panel5->hide();
        Animation::fadeTo($this->rect5, 50, 0.0);
        $this->button->show();
        });
    }

    /**
     * @event userStatus.click-Left 
     */
    function doUserStatusClickLeft(UXMouseEvent $e = null)
    {    
        app()->showForm('usrStatus');
    }

    /**
     * @event netStatus.click-Left 
     */
    function doNetStatusClickLeft(UXMouseEvent $e = null)
    {    
        $this->log->text .= "\n~: check net";
        $this->edit->text = "";
        $ethernetEnabled = file_get_contents('http://ya.ru') !== false;
        
        if ($ethernetEnabled) {
            $this->netStatus->fillColor = "#50aa5e";
            $this->log->text .= "\nИнтернет-подключение имеется. Терминал подключен к серверу HentaiNET. Вы можете полноценно пользоваться терминалом. \n";
        } else {
            $this->netStatus->fillColor = "#cca433";
            $this->log->text .= "\nИнтернет-подключение отсутствует. Терминал не подключен к серверу HentaiNET, но вы можете пользоваться терминалом, хоть некоторые функции работать и не будут. \n";
        }
    }












}
