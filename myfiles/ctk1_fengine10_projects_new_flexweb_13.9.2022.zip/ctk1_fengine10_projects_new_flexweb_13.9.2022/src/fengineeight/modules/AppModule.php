<?php
namespace fengineeight\modules;

use std, gui, framework, fengineeight;
use php\time\Time;


class AppModule extends AbstractModule
{
    
    /**
     * @event script.action 
     */
    function doScriptAction(ScriptEvent $e = null)
    {    
        file_put_contents('loaderLog.txt', "\n[LOADER] - Startup time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
        file_put_contents('loaderLog.txt', "[LOADER] - FLEXengine Next Generation Starting Core...\r\n", FILE_APPEND);
        file_put_contents('loaderLog.txt', "[LOADER] - FLEXengine Next Generation Loaded!\r\n", FILE_APPEND);
        file_put_contents('loaderLog.txt', "[LOADER] - FLEXengine Version: 8.0.311_dev\r\n", FILE_APPEND);
        file_put_contents('loaderLog.txt', "[LOADER] - Modules loading...\r\n", FILE_APPEND);
        file_put_contents('loaderLog.txt', "[CTK] - CTK UI API Loaded!\r\n", FILE_APPEND);
    }

}
