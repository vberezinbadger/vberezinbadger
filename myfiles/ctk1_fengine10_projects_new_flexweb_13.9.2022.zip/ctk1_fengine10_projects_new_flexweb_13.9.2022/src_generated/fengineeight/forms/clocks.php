<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use action\Animation; 
use action\Element; 


class clocks extends AbstractForm
{


    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle3, 130, 0.6);

        
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle3, 130, 0.3);

        
    }



    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle, 130, 0.6);

        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle, 130, 0.3);

        
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->minimizeForm('note');

        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->shutdown();

        
    }




    /**
     * @event circle10.mouseEnter 
     */
    function doCircle10MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle9, 130, 0.6);

        
    }

    /**
     * @event circle10.mouseExit 
     */
    function doCircle10MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle9, 130, 0.3);

        
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(300, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }




    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this, 1);
		$this->hide();

        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		waitAsync(300, function () use ($e, $event) {
			$this->show();
			Animation::fadeIn($this, 130);
		});

        
    }



    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->label3, 130, 1.0);
		Animation::fadeTo($this->rect9, 130, 0.1);

        
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->label3, 130, 0.0);
		Animation::fadeTo($this->rect9, 130, 0.0);

        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel->show();
		waitAsync(300, function () use ($e, $event) {
			Animation::fadeIn($this->panel, 130);
		});

        
    }

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 130, 0.1);

        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 130, 0.0);

        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 50, 0.2);

        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->rect5, 50, 0.1);

        
    }

    /**
     * @event circle6.mouseEnter 
     */
    function doCircle6MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle5, 130, 0.6);

        
    }

    /**
     * @event circle6.mouseExit 
     */
    function doCircle6MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle5, 130, 0.3);

        
    }

    /**
     * @event circle6.click-Left 
     */
    function doCircle6ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel3, 130);
		waitAsync(300, function () use ($e, $event) {
			$this->panel3->hide();
		});

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel3->show();
		waitAsync(300, function () use ($e, $event) {
			Animation::fadeIn($this->panel3, 130);
		});

        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		waitAsync(500, function () use ($e, $event) {
			Element::setText($this->label12, uiText($this->edit));
			Animation::fadeOut($this->panel3, 130);
			waitAsync(300, function () use ($e, $event) {
				$this->panel3->hide();
				$this->panelAlt->show();
			});
		});

        
    }

    /**
     * @event circle11.mouseEnter 
     */
    function doCircle11MouseEnter(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle9, 130, 0.6);

        
    }

    /**
     * @event circle11.mouseExit 
     */
    function doCircle11MouseExit(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeTo($this->circle9, 130, 0.3);

        
    }

    /**
     * @event circle11.click-Left 
     */
    function doCircle11ClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(300, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event label4.construct 
     */
    function doLabel4Construct(UXEvent $e = null)
    {    
        
    }









































}
