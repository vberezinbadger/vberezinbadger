<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class settings extends AbstractForm
{


    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('doneCreatUser');
    }

    /**
     * @event image5.click-Left 
     */
    function doImage5ClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('doneCreatUser');
    }

    /**
     * @event link.action 
     */
    function doLinkAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		browse('https://github.com/hentai-team/terminal');

        
    }

    /**
     * @event linkAlt.action 
     */
    function doLinkAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		browse('https://vk.com/kolibracorp.hterminal');

        
    }

    /**
     * @event link3.action 
     */
    function doLink3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		browse('https://vk.com/star_buttefly_original');

        
    }








}
