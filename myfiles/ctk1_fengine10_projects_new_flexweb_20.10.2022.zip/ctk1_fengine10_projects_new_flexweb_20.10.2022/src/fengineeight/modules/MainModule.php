<?php
namespace fengineeight\modules;

use std, gui, framework, fengineeight;


class MainModule extends AbstractModule
{

}