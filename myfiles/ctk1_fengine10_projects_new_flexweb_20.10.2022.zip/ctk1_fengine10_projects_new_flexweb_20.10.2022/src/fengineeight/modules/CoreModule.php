<?php
namespace fengineeight\modules;

use php\gui\framework\AbstractModule;


class CoreModule extends AbstractModule
{

}