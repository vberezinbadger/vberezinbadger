<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;

use php\gui\UXWebEngine;
use action\Element;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\UXTab;
use php\time\Time;
use php\gui\event\UXEvent;
use php\gui\UXWebView;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;


class domainInfo extends AbstractForm
{
    

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('domainInfo');
    }


}
