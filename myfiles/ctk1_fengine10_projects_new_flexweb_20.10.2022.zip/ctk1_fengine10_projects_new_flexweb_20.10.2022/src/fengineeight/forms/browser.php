<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;
use php\gui\UXWebViewWrapper;
use php\gui\UXWebEngine;
use php\gui\UXWebView;
use php\gui\UXWebViewWrapper;
use action\Element;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\UXTab;
use php\time\Time;
use php\gui\event\UXEvent;
use php\gui\UXWebView;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;


class browser extends AbstractForm
{

    $version = "1.0.010";
    
    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Animation::fadeTo($this->circle, 130, 0.6);
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Animation::fadeTo($this->circle, 130, 0.3);
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm($this->getContextFormName());
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
        app()->minimizeForm($this->getContextFormName());
    }

    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Animation::fadeTo($this->circle3, 130, 0.6);
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {
        
        
        // Generated
        $e = $event ?: $e; // legacy code from 16 rc-2
        
        Animation::fadeTo($this->circle3, 130, 0.3);
    }










    
    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        file_put_contents('termLog.txt', "\nStartup time: " . Time::now()->toString('dd.MM.yyyy HH:mm') . "\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "FLEXweb, v1.0.010_dev.\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "Kolibra Studios 2022. All rights reserved.\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM]: loading WebS Modules list...\r\n", FILE_APPEND);
    }
    
    /**
     * @event show
     */
    function doShow(UXWindowEvent $e = null)
    {    
        file_put_contents('termLog.txt', "[TERM]: WebSModule started!\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: webForm loaded!\r\n", FILE_APPEND);
        file_put_contents('termLog.txt', "[TERM] > [CTK]: UI Elements loaded!\r\n", FILE_APPEND);
        
        # CheckEthernet
        
        $ethernetEnabled = file_get_contents('https://kolibra.site/flexweb/webs') !== false;
        
        if ($ethernetEnabled) {
            echo "\nWebS Connected! \n";
        } else {
            echo "\nWebS Disconected! \n";
            $this->loadForm('errorNetwork');
        }  
        
        # noWindowCirlceConfig Check
        
        if (File::of('config/noCircleWindow.true')->isFile()) {
            $this->rect8->arcWidth = 0;
            $this->rect8->arcHeight = 0;
        
            $this->rectAlt->arcWidth = 0;
            $this->rectAlt->arcHeight = 0;
        
            $this->rect->arcWidth = 0;
            $this->rect->arcHeight = 0;
        } else {
            $this->rect8->arcWidth = 18;
            $this->rect8->arcHeight = 18;
        
            $this->rectAlt->arcWidth = 16;
            $this->rectAlt->arcHeight = 16;
        
            $this->rect->arcWidth = 16;
            $this->rect->arcHeight = 16;
        }    
    }











    /**
     * @event rect5.click-Left 
     */
    function doRect5ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event image6.click 
     */
    function doImage6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect4.click 
     */
    function doRect4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label.click 
     */
    function doLabelClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect3.click 
     */
    function doRect3Click(UXMouseEvent $e = null)
    {    
        
    }


    /**
     * @event rect6.click 
     */
    function doRect6Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect7.click 
     */
    function doRect7Click(UXMouseEvent $e = null)
    {    
        
    }



    /**
     * @event image3.click 
     */
    function doImage3Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circleAlt.click 
     */
    function doCircleAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event edit.click-Left 
     */
    function doEditClickLeft(UXMouseEvent $e = null)
    {    
        app()->showFormAndWait('createFolder');
    }

    /**
     * @event domainStatus.click-Left 
     */
    function doDomainStatusClickLeft(UXMouseEvent $e = null)
    {    
        $domainSecure = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '/certificate/secureCertificate.txt');
        
        if ($domainSecure == "siteSystemSecureEnabled = true") {
            app()->showFormAndWait('domainInfo');
        } if ($domainSecure !== "siteSystemSecureEnabled = true") {
            app()->showFormAndWait('checkDomain');
        }
    }

    /**
     * @event rect24.click-Left 
     */
    function doRect24ClickLeft(UXMouseEvent $e = null)
    {    
        $domainSecure = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '/certificate/secureCertificate.txt');
        
        if ($domainSecure == "siteSystemSecureEnabled = true") {
            app()->showFormAndWait('domainInfo');
        } if ($domainSecure !== "siteSystemSecureEnabled = true") {
            app()->showFormAndWait('checkDomain');
        }
    }



















































}
