<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class loader extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $ethernetEnabled = file_get_contents('https://kolibra.site/flexweb/webs') !== false; 
        $ethernetDisabled = file_get_contents('https://kolibra.site/flexweb/webs') == false; 
        
        Element::setText($this->label4, 'Loading modules...');
        waitAsync(2300, function () use ($e, $event) {
            Element::setText($this->label4, 'Loading FLEXweb Engine...');
            waitAsync(3500, function () use ($e, $event) {
                Element::setText($this->label4, 'Checking connect to: WebS Central Server...');
                waitAsync(3500, function () use ($e, $event) {
                    $this->loadForm('browser');
        });});});
    }

}
