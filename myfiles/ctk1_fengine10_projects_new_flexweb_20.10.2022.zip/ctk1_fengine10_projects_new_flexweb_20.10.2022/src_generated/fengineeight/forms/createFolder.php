<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;

use php\gui\UXWebEngine;
use action\Element;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\UXTab;
use php\time\Time;
use php\gui\event\UXEvent;
use php\gui\UXWebView;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;


class createFolder extends AbstractForm
{
    
    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $e = null)
    {
$e = $event ?: $e; // legacy code from 16 rc-2

		waitAsync(200, function () use ($e, $event) {
		});

        $siteOnBaza = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '');
        $domainSecure = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '/certificate/secureCertificate.txt');
        $regionName = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '/certificate/regionName.txt');
        $siteName = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '/certificate/siteName.txt');
        $author = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '/certificate/author.txt');
        
        if ($siteOnBaza == "created=true") {
            app()->hideForm('createFolder');
            if ($domainSecure == 'siteSystemSecureEnabled = true') {
                
                // Set Info Domain
                $this->form('domainInfo')->author->text = $author;
                $this->form('domainInfo')->siteName->text = $siteName;
                $this->form('domainInfo')->regionName->text = $regionName;
                
                // Security Icon Set
                $this->form('browser')->rect24->fillColor = '#a5d4a4';
                $this->form('browser')->rect24->strokeColor = '#729571';
            } else {
                // Security Icon Set
                $this->form('browser')->rect24->fillColor = '#f2f2f2';
                $this->form('browser')->rect24->strokeColor = '#b3b3b3';
            }
            $this->form('browser')->browser->engine->url = 'https://kolibra.site/flexweb/webs/sites/' . $this->edit->text . '/main.html';
            Element::setText($this->form('browser')->edit, uiText($this->edit));
            $this->form('browser')->netStatus->text = 'Connecting...';
            waitAsync(1200, function () use ($e, $event) {
                $this->form('browser')->netStatus->text = 'Rendering page...';
                    waitAsync(200, function () use ($e, $event) {
                        $this->form('browser')->browser->engine->reload();
                        $this->form('browser')->netStatus->text = 'Ready!';
            });});
        } else {
            app()->hideForm('createFolder');
            $this->form('browser')->browser->engine->url = 'https://kolibra.site/flexweb/webs/sites/webs_error404.html';
            $this->form('browser')->edit->text = "Ошибка 404";
            $this->form('browser')->netStatus->text = 'Connect...';
            waitAsync(1200, function () use ($e, $event) {
                $this->form('browser')->netStatus->text = 'Not found page, rendering error page (404)...';
                    waitAsync(200, function () use ($e, $event) {
                        $this->form('browser')->browser->engine->reload();
                        $this->form('browser')->netStatus->text = 'Ready! Error code: 404 (webs_page_not_found).';
            });});
        }
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('createFolder');
    }


}
