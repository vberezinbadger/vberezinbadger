<?php
namespace app\forms;

use php\framework\Logger;
use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 
use php\gui\event\UXEvent; 
use action\Animation; 
use php\gui\event\UXWindowEvent; 
use php\gui\event\UXKeyEvent; 
use action\Element; 


class calculator extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event minButton.click-Left 
     */
    function doMinButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->minimizeForm('calculator');
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }








    /**
     * @event labelAlt.mouseDown-Left 
     */
    function doLabelAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->label4->text = "onWindowBlinkFX_enabled: true";
        $this->label5->text = "onMouseAttached_status: 0x01";
    }

    /**
     * @event labelAlt.mouseUp-Left 
     */
    function doLabelAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->label4->text = "onWindowBlinkFX_enabled: false";
        $this->label5->text = "onMouseAttached_status: 0x00";
    }


    /**
     * @event buttonClear.click-Left 
     */
    function doButtonClearClickLeft(UXMouseEvent $e = null)
    {
        global $operation;
        
        $operation = false;
        
        $this->edit->text = "";
    }

    /**
     * @event buttonClear.mouseEnter 
     */
    function doButtonClearMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event buttonClear.mouseExit 
     */
    function doButtonClearMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event buttonSplit.click-Left 
     */
    function doButtonSplitClickLeft(UXMouseEvent $e = null)
    {
        global $operation;
        
        if (!$operation) {
            $this->edit->text .= $e->sender->text;
            $operation = $e->sender->text;
        }
    }

    /**
     * @event buttonSplit.mouseEnter 
     */
    function doButtonSplitMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event buttonSplit.mouseExit 
     */
    function doButtonSplitMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button7.click-Left 
     */
    function doButton7ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button7.mouseEnter 
     */
    function doButton7MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button7.mouseExit 
     */
    function doButton7MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button8.click-Left 
     */
    function doButton8ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button8.mouseEnter 
     */
    function doButton8MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button8.mouseExit 
     */
    function doButton8MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button9.click-Left 
     */
    function doButton9ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button9.mouseEnter 
     */
    function doButton9MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button9.mouseExit 
     */
    function doButton9MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button4.mouseEnter 
     */
    function doButton4MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button4.mouseExit 
     */
    function doButton4MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button5.click-Left 
     */
    function doButton5ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button5.mouseEnter 
     */
    function doButton5MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button5.mouseExit 
     */
    function doButton5MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button6.click-Left 
     */
    function doButton6ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button6.mouseEnter 
     */
    function doButton6MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button6.mouseExit 
     */
    function doButton6MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button1.click-Left 
     */
    function doButton1ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button1.mouseEnter 
     */
    function doButton1MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button1.mouseExit 
     */
    function doButton1MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button2.click-Left 
     */
    function doButton2ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button2.mouseEnter 
     */
    function doButton2MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button2.mouseExit 
     */
    function doButton2MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button3.mouseEnter 
     */
    function doButton3MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button3.mouseExit 
     */
    function doButton3MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button0.click-Left 
     */
    function doButton0ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= $e->sender->text;
    }

    /**
     * @event button0.mouseEnter 
     */
    function doButton0MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button0.mouseExit 
     */
    function doButton0MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event button16.click-Left 
     */
    function doButton16ClickLeft(UXMouseEvent $e = null)
    {
        $this->edit->text .= ".";
    }

    /**
     * @event button16.mouseEnter 
     */
    function doButton16MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event button16.mouseExit 
     */
    function doButton16MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event buttonMult.click-Left 
     */
    function doButtonMultClickLeft(UXMouseEvent $e = null)
    {
        global $operation;
        
        if (!$operation){
        
            $this->edit->text .= $e->sender->text;
        
            $operation = $e->sender->text;
        
        }
    }

    /**
     * @event buttonMult.mouseEnter 
     */
    function doButtonMultMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event buttonMult.mouseExit 
     */
    function doButtonMultMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event buttonMin.click-Left 
     */
    function doButtonMinClickLeft(UXMouseEvent $e = null)
    {
        global $operation;
        
        if (!$operation){
        
            $this->edit->text .= $e->sender->text;
        
            $operation = $e->sender->text;
        
        }
    }

    /**
     * @event buttonMin.mouseEnter 
     */
    function doButtonMinMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event buttonMin.mouseExit 
     */
    function doButtonMinMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event buttonPlus.click-Left 
     */
    function doButtonPlusClickLeft(UXMouseEvent $e = null)
    {
        global $operation;
        
        if (!$operation){
        
            $this->edit->text .= $e->sender->text;
        
            $operation = $e->sender->text;
        
        }
    }

    /**
     * @event buttonPlus.mouseEnter 
     */
    function doButtonPlusMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 1.0);
    }

    /**
     * @event buttonPlus.mouseExit 
     */
    function doButtonPlusMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 140, 0.6);
    }

    /**
     * @event buttonResult.click-Left 
     */
    function doButtonResultClickLeft(UXMouseEvent $e = null)
    {
        
        
        global $operation;
        
        if ($operation){ 
        
            $numbers = explode($operation, $this->edit->text);
        
            switch ($operation){ 
        
                case "+":
        
                    $result = $numbers[0] + $numbers[1];
        
                break;
        
                case "-":
        
                    $result = $numbers[0] - $numbers[1];
        
                break;
        
                case "×":
        
                    $result = $numbers[0] * $numbers[1];
        
                break;
        
                case "÷":
        
                    $result = $numbers[0] / $numbers[1];
        
                break;
        
            }
        
            $this->edit->text = $result;
        
            $operation = false;
        
        }
    }

    /**
     * @event label7.mouseDown-Left 
     */
    function doLabel7MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->label4->text = "onWindowBlinkFX_enabled: true";
        $this->label5->text = "onMouseAttached_status: 0x01";
    }

    /**
     * @event label7.mouseUp-Left 
     */
    function doLabel7MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->label4->text = "onWindowBlinkFX_enabled: false";
        $this->label5->text = "onMouseAttached_status: 0x00";
    }

    /**
     * @event image6.click-Left 
     */
    function doImage6ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event image7.click-Left 
     */
    function doImage7ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event image8.click-Left 
     */
    function doImage8ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event circle7.click-Left 
     */
    function doCircle7ClickLeft(UXMouseEvent $e = null)
    {
        app()->minimizeForm('calculator');
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->rect5, 160, 1.0);
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this->rect5, 160, 0.0);
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->panel->hide();
    }

    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->rect10, 160, 1.0);
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->rect10, 160, 0.0);
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        $this->panel->show();
    }

    /**
     * @event label11.mouseDown-Left 
     */
    function doLabel11MouseDownLeft(UXMouseEvent $e = null)
    {
        $this->label4->text = "onWindowBlinkFX_enabled: true";
        $this->label5->text = "onMouseAttached_status: 0x01";
    }

    /**
     * @event label11.mouseUp-Left 
     */
    function doLabel11MouseUpLeft(UXMouseEvent $e = null)
    {
        $this->label4->text = "onWindowBlinkFX_enabled: false";
        $this->label5->text = "onMouseAttached_status: 0x00";
    }

    /**
     * @event image12.click-Left 
     */
    function doImage12ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event image13.click-Left 
     */
    function doImage13ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event image14.click-Left 
     */
    function doImage14ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event circle12.click-Left 
     */
    function doCircle12ClickLeft(UXMouseEvent $e = null)
    {
        app()->minimizeForm('calculator');
    }

    /**
     * @event circle13.click-Left 
     */
    function doCircle13ClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event button10.mouseEnter 
     */
    function doButton10MouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->rect8, 160, 1.0);
    }

    /**
     * @event button10.mouseExit 
     */
    function doButton10MouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($this->rect8, 160, 0.0);
    }

    /**
     * @event button10.action 
     */
    function doButton10Action(UXEvent $e = null)
    {
        $this->panelAlt->hide();
    }

    /**
     * @event image9.click-Left 
     */
    function doImage9ClickLeft(UXMouseEvent $e = null)
    {    
        $this->panelAlt->show();
    }

    /**
     * @event label8.click-Left 
     */
    function doLabel8ClickLeft(UXMouseEvent $e = null)
    {    
        $this->panelAlt->show();
    }

    /**
     * @event rect6.mouseDown-Left 
     */
    function doRect6MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->panelAlt->show();
    }







}
