<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 


class MainForm extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event minButton.click-Left 
     */
    function doMinButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->minimizeForm('MainForm');
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event edit.mouseEnter 
     */
    function doEditMouseEnter(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 1;
    }

    /**
     * @event edit.mouseExit 
     */
    function doEditMouseExit(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
    }

    /**
     * @event edit.click 
     */
    function doEditClick(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 2;
        $this->rect3->strokeColor = '#0088ff';
        $this->rect3->fillColor = '#ffffff';
    }

    /**
     * @event label3.click 
     */
    function doLabel3Click(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event label4.click 
     */
    function doLabel4Click(UXMouseEvent $e = null)
    {
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event label5.click 
     */
    function doLabel5Click(UXMouseEvent $e = null)
    {
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event labelAlt.mouseDown-Left 
     */
    function doLabelAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->label4->text = "onWindowBlinkFX_enabled: true";
        $this->label5->text = "onMouseAttached_status: 0x01";
    }

    /**
     * @event labelAlt.mouseUp-Left 
     */
    function doLabelAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->label4->text = "onWindowBlinkFX_enabled: false";
        $this->label5->text = "onMouseAttached_status: 0x00";
    }

    /**
     * @event labelAlt.click-Right 
     */
    function doLabelAltClickRight(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel->x += 1;
		$this->panel->y += 1;

        
    }





}
