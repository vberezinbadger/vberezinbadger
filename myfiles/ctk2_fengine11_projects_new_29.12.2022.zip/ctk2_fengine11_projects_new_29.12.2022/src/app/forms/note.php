<?php
namespace app\forms;

use std, gui, framework, app;


class note extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

}
