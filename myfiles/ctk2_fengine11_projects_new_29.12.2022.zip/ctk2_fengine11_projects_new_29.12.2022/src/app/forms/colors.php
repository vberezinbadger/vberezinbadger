<?php
namespace app\forms;

use std, gui, framework, app;


class colors extends AbstractForm
{

}