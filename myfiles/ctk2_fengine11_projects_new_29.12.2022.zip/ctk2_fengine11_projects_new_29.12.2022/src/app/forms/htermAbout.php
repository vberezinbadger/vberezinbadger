<?php
namespace app\forms;

use std, gui, framework, app;


class htermAbout extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {
        app()->hideForm('about');
    }

    /**
     * @event labelAlt.mouseDown-Left 
     */
    function doLabelAltMouseDownLeft(UXMouseEvent $e = null)
    {
        
    }

    /**
     * @event labelAlt.mouseUp-Left 
     */
    function doLabelAltMouseUpLeft(UXMouseEvent $e = null)
    {
        
    }

    /**
     * @event labelAlt.click-Right 
     */
    function doLabelAltClickRight(UXMouseEvent $e = null)
    {    
        
    }

}
