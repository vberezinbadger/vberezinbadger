<?php
namespace app\forms;

use std, gui, framework, app;


class debugChangeColor extends AbstractForm
{

    /**
     * @event label.click-Left 
     */
    function doLabelClickLeft(UXMouseEvent $e = null)
    {    
        $color = $this->edit->text;
        
        $this->form('hterm')->label->style = '-fx-background-color: linear-gradient($color, $color); -fx-background-radius: 10 10 0 0;';   
    }

}
