<?php
namespace app\modules;

use std, gui, framework, app;


class nigger extends AbstractModule
{
    
    /**
     * @event action 
     */
    function doAction(ScriptEvent $e = null)
    {
        
        $username = file_get_contents('bash/usermgr.username');
        
        $workspaceName = file_get_contents('bash/usermgr.workspacename');
        
        $session = "" . $username . "@" . $workspaceName . "";
        
        $version = "1.0.010";
        
        $newVersion = file_get_contents('https://raw.githubusercontent.com/hentai-team/memphis/main/versions/latestver.txt');
        
        $this->log->text .= "\n" . $session . ": nigger";
        $this->log->text .= "\nНиггерс \n";
        $this->edit->text = "";
        echo "\n[BASH] >> [HELLO]: Ниггерс \n";
        waitAsync(500, function () use ($e, $event) {
            $this->circle4->fillColor = '#333333';
            waitAsync(500, function () use ($e, $event) {
                $this->circle4->fillColor = '#52c65f';
                            
        waitAsync(500, function () use ($e, $event) {
            $this->form('led')->circle4->fillColor = '#333333';
            waitAsync(500, function () use ($e, $event) {
                $this->form('led')->circle4->fillColor = '#52c65f';
        });});
                    
        $this->form('led')->labelAlt->text = "Я не ниггер!";
        $this->form('led')->label3->text = "Ты меня обидел! Я тебя взломаю!";        
        });});
    }

    /**
     * @event construct 
     */
    function doConstruct(ScriptEvent $e = null)
    {    

        $username = file_get_contents('bash/usermgr.username');
        
        $workspaceName = file_get_contents('bash/usermgr.workspacename');
        
        $session = "" . $username . "@" . $workspaceName . "";
        
        $version = "1.0.010";
        
        $newVersion = file_get_contents('https://raw.githubusercontent.com/hentai-team/memphis/main/versions/latestver.txt');
        
        $this->log->text .= "\n" . $session . ": nigger";
        $this->log->text .= "\nНиггерс \n";
        $this->edit->text = "";
        echo "\n[BASH] >> [HELLO]: Ниггерс \n";
        waitAsync(500, function () use ($e, $event) {
            $this->circle4->fillColor = '#333333';
            waitAsync(500, function () use ($e, $event) {
                $this->circle4->fillColor = '#52c65f';
                            
        waitAsync(500, function () use ($e, $event) {
            $this->form('led')->circle4->fillColor = '#333333';
            waitAsync(500, function () use ($e, $event) {
                $this->form('led')->circle4->fillColor = '#52c65f';
        });});
                    
        $this->form('led')->labelAlt->text = "Я не ниггер!";
        $this->form('led')->label3->text = "Ты меня обидел! Я тебя взломаю!";        
        });});
    }

}
