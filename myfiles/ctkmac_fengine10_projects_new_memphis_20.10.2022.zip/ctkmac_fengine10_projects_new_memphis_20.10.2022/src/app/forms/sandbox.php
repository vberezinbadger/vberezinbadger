<?php
namespace app\forms;

use std, gui, framework, app;


class sandbox extends AbstractForm
{

    $version = "1.0.010";
    
    
    /**
     * @event circle.click-Left 
     */
    function doCircleClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('sandbox');
    }

    /**
     * @event textArea.globalKeyPress-Enter 
     */
    function doTextAreaGlobalKeyPressEnter(UXKeyEvent $e = null)
    {    
        $this->textArea;
    }





}
