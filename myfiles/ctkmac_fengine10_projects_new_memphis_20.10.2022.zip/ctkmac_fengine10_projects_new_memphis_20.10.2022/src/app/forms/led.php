<?php
namespace app\forms;

use std, gui, framework, app;


class led extends AbstractForm
{

    $version = "1.0.010";
    
    
    /**
     * @event circle.click-Left 
     */
    function doCircleClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circleAlt.click-Left 
     */
    function doCircleAltClickLeft(UXMouseEvent $e = null)
    {    
        
    }




}
