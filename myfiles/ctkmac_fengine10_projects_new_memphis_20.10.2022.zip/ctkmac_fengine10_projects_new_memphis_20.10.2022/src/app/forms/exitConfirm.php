<?php
namespace app\forms;

use std, gui, framework, app;


class exitConfirm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $username = file_get_contents('bash/usermgr.username');
        $workspaceName = file_get_contents('bash/usermgr.workspacename');
        $session = "" . $username . "@" . $workspaceName . "";
        
        $this->form('main')->log->text .= "\n" . $session . ": memphisSH.sessionID.setParam -status gayUser";
        $this->form('main')->log->text .= "\nStatus: Gay. \nYou're fucking gay! You deserve to be gay, you fucking bastard! \n";
        $this->form('main')->edit->text = "";
        browse('https://github.com/hentai-team/memphis/blob/main/messages/gay.md');
        $this->form('led')->circle4->fillColor = '#52c65f';
        $this->form('led')->labelAlt->text = "You fucking gay!";
        $this->form('led')->label3->text = "Fuck you, man! You fucking stinky gay!";
        waitAsync(500, function () use ($e, $event) {
            $this->form('main')->circle4->fillColor = '#333333';
            waitAsync(500, function () use ($e, $event) {
                $this->form('main')->circle4->fillColor = '#52c65f';
        });});
        app()->hideForm('exitConfirm');
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $username = file_get_contents('bash/usermgr.username');
        $workspaceName = file_get_contents('bash/usermgr.workspacename');
        $session = "" . $username . "@" . $workspaceName . "";
        
        $this->form('main')->log->text .= "\n" . $session . ": memphisSH.sessionID.setParam -status coolPerson";
        $this->form('main')->log->text .= "\nStatus: Cool Person. \nYou are the coolest person! Good luck to you and be even cooler! The world is getting better with people like you! \n";
        $this->form('main')->edit->text = "";
        browse('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
        $this->form('led')->circle4->fillColor = '#52c65f';
        $this->form('led')->labelAlt->text = "You not gay!";
        $this->form('led')->label3->text = "You have proved that you are straight! You're a cool person! Keep it up !";
        waitAsync(500, function () use ($e, $event) {
            $this->form('main')->circle4->fillColor = '#333333';
            waitAsync(500, function () use ($e, $event) {
                $this->form('main')->circle4->fillColor = '#52c65f';
        });});
        app()->hideForm('exitConfirm');
    }
}
