<?php
namespace app\forms;

use std, gui, framework, app;


class color extends AbstractForm
{

}