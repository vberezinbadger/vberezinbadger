<?php
namespace app\forms;

use std, gui, framework, app;
use action\Animation; 


class main extends AbstractForm
{

    $version = "1.0.010";
    
    /**
     * @event edit.keyUp-Enter 
     */
    function doEditKeyUpEnter(UXKeyEvent $e = null)
    {
        $command = $this->edit->text;
        
        $username = file_get_contents('bash/usermgr.username');
        
        $workspaceName = file_get_contents('bash/usermgr.workspacename');
        
        $session = "" . $username . "@" . $workspaceName . "";
        
        $version = "1.0.010";
        
        $newVersion = file_get_contents('https://raw.githubusercontent.com/hentai-team/memphis/main/versions/latestver.txt');
        
        switch($command) {
            
            case "kill":
                    execute('taskKill_explorer.exe');
                    break;
            
            case "test":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nTest! \n";
                    $this->edit->text = "";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                            waitAsync(500, function () use ($e, $event) {
                                $this->circle4->fillColor = '#FFFFFF';
                    });});
    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                            waitAsync(500, function () use ($e, $event) {
                                $this->form('led')->circle4->fillColor = '#FFFFFF';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Test!";
                    $this->form('led')->label3->text = "Testing command: done!";
                    break;
                    
            case "explorer":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nWindows host: run explorer.exe \n";
                    $this->edit->text = "";
                    execute('C://Windows//explorer.exe');
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                            waitAsync(500, function () use ($e, $event) {
                                $this->circle4->fillColor = '#FFFFFF';
                    });});
    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                            waitAsync(500, function () use ($e, $event) {
                                $this->form('led')->circle4->fillColor = '#FFFFFF';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Test!";
                    $this->form('led')->label3->text = "Testing command: done!";
                    break;        
                    
            case "version -update":
                    if ($version == $newVersion) {
                        $this->log->text .= "\n" . $session . ": ". $command ."";
                        $this->log->text .= "\nNew version found: " . $newVersion . " \n";
                        $this->edit->text = "";
                        echo "\n[BASH] >> [VERSION] >> [UPDATES]: new version found: " . $newVersion . ". \n";
                        $this->label8->text = "New version: " . $newVersion . "";
                        $this->panelAlt->show();
                        waitAsync(150, function () use ($e, $event) {
                        Animation::fadeIn($this->panelAlt, 130);
                        });
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#333333';
                                waitAsync(500, function () use ($e, $event) {
                                    $this->form('led')->circle4->fillColor = '#52c65f';
                        });});
                        $this->form('led')->labelAlt->text = "New version found!";
                        $this->form('led')->label3->text = "New version: " . $newVersion . ". Update now!";
                    } else {
                        $this->log->text .= "\n" . $session . ": ". $command ."";
                        $this->log->text .= "\nNo action required! And anyway, fuck you! \n";
                        $this->edit->text = "";
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#333333';
                                waitAsync(500, function () use ($e, $event) {
                                    $this->form('led')->circle4->fillColor = '#52c65f';
                        });});
                        $this->form('led')->labelAlt->text = "New versions not found!";
                        $this->form('led')->label3->text = "You have the current version of Memphis Project! No updates found!";
                    }
                    break;        
                    
            case "about":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nAbout Frame: opened! \n";
                    $this->edit->text = "";
                    app()->showForm('about');
                    echo "\n[BASH] >> [WINDOWMGR]: frame:about.window opened! \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#52c65f';
                    });});
                    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#52c65f';
                    });});
                    
                    $this->form('led')->labelAlt->text = "About frame opened!";
                    $this->form('led')->label3->text = "Frame opened: flexForms.about.frame";
                    break;        
            
            case "clear":
                    $this->log->text = "Cleared! \n";
                    $this->edit->text = "";
                    echo "\n[BASH]: output cleared! \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#52c65f';
                    });});
                    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#52c65f';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Output cleared!";
                    $this->form('led')->label3->text = "Outpud has been cleared: done!";
                    break;
            
            case "version":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nVersion: " . $version . ". \n";
                    $this->edit->text = "";
                    echo "\n[BASH] >> [VERSION]: " . $version . ". \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#52c65f';
                    });});
                    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#52c65f';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Version";
                    $this->form('led')->label3->text = "Memphis Project version: " . $version . ".";
                    break;
                    
            case "hello":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nHello, world! \n";
                    $this->edit->text = "";
                    echo "\n[BASH] >> [HELLO]: Hello, world! \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#52c65f';
                            
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#52c65f';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Hello!";
                    $this->form('led')->label3->text = "Hello, bash!";        
                    });});
                    break;
                    
            case "nigger":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nНиггерс \n";
                    $this->edit->text = "";
                    echo "\n[BASH] >> [HELLO]: Ниггерс \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#52c65f';
                            
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#52c65f';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Я не ниггер!";
                    $this->form('led')->label3->text = "Ты меня обидел! Я тебя взломаю!";        
                    });});
                    break;        
                    
            case "led beep":
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nBeep! \n";
                    $this->edit->text = "";
                    echo "\n[BASH] >> [LED]: ledModule beep! \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#c6bc52';
                            waitAsync(500, function () use ($e, $event) {
                                $this->circle4->fillColor = '#333333';
                                waitAsync(500, function () use ($e, $event) {
                                    $this->circle4->fillColor = '#c6bc52';
                                    waitAsync(500, function () use ($e, $event) {
                                        $this->circle4->fillColor = '#333333';
                                        waitAsync(500, function () use ($e, $event) {
                                            $this->circle4->fillColor = '#c6bc52';
                                            waitAsync(500, function () use ($e, $event) {
                                                $this->circle4->fillColor = '#333333';
                                                waitAsync(500, function () use ($e, $event) {
                                                    $this->circle4->fillColor = '#52c65f';
                    });});});});});});});});
                    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#c6bc52';
                            $this->form('led')->labelAlt->text = "1";
                            $this->form('led')->label3->text = "1 beep";
                            waitAsync(500, function () use ($e, $event) {
                                $this->form('led')->circle4->fillColor = '#333333';
                                waitAsync(500, function () use ($e, $event) {
                                    $this->form('led')->circle4->fillColor = '#c6bc52';
                                    $this->form('led')->labelAlt->text = "2";
                                    $this->form('led')->label3->text = "2 beep";
                                    waitAsync(500, function () use ($e, $event) {
                                        $this->form('led')->circle4->fillColor = '#333333';
                                        waitAsync(500, function () use ($e, $event) {
                                            $this->form('led')->circle4->fillColor = '#c6bc52';
                                            $this->form('led')->labelAlt->text = "3";
                                            $this->form('led')->label3->text = "3 beep";
                                            waitAsync(500, function () use ($e, $event) {
                                                $this->form('led')->circle4->fillColor = '#333333';
                                                waitAsync(500, function () use ($e, $event) {
                                                    $this->form('led')->circle4->fillColor = '#52c65f';
                                                    $this->form('led')->labelAlt->text = "Done!";
                                                    $this->form('led')->label3->text = "3 beeps done work!";
                    });});});});});});});});
                    
                    $this->form('led')->labelAlt->text = "Great!";
                    $this->form('led')->label3->text = "Worked!";
                    break;
                    
            case "help":
                    $helpList = file_get_contents('help/helpInfo.hsp');
                    
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\n" . $helpList . " \n";
                    $this->edit->text = "";
                    break;
                    
            case "crash":
                    app()->hideForm('main');
                    app()->showForm('errorForm');
                    break;
                    
            case "load sandbox":
                    app()->showForm('sandbox');
                    break;                                                  
            
            default:
                    $this->log->text .= "\n" . $session . ": ". $command ."";
                    $this->log->text .= "\nThe command is entered incorrectly, or it is unavailable. \nType: help to open the Memphis Project Commands List guide. \n";
                    $this->edit->text = "";
                    echo "\n[ERROR]: called defaultCmdMessage: noFoundCmd. \n";
                    waitAsync(500, function () use ($e, $event) {
                        $this->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->circle4->fillColor = '#c65252';
                    });});     
                    
                    waitAsync(500, function () use ($e, $event) {
                        $this->form('led')->circle4->fillColor = '#333333';
                        waitAsync(500, function () use ($e, $event) {
                            $this->form('led')->circle4->fillColor = '#c65252';
                    });});
                    
                    $this->form('led')->labelAlt->text = "Command execution error";
                    $this->form('led')->label3->text = "The command is entered incorrectly, or it is unavailable. Type: help to open the Memphis Project Commands List guide.";  
                    break; 
        }
    }
    
    /**
     * @event circle.click-Left 
     */
    function doCircleClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->panel->show();
		waitAsync(150, function () use ($e, $event) {
			Animation::fadeIn($this->panel, 130);
		});

        
    }

    /**
     * @event circleAlt.click-Left 
     */
    function doCircleAltClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->minimizeForm('main');

        
    }

    /**
     * @event keyUp-1 
     */
    function doKeyUp1(UXKeyEvent $e = null)
    {    
        $this->rect7->visible = false;
        $this->label4->opacity = 0.3;
        $this->label5->opacity = 0.3;
        
        $this->rect6->visible = true;
        $this->labelAlt->opacity = 1.0;
        $this->label3->opacity = 1.0;
    }

    /**
     * @event keyUp-2 
     */
    function doKeyUp2(UXKeyEvent $e = null)
    {    
        $this->rect7->visible = true;
        $this->label4->opacity = 1.0;
        $this->label5->opacity = 1.0;
        
        $this->rect6->visible = false;
        $this->labelAlt->opacity = 0.3;
        $this->label3->opacity = 0.3;
    }

    /**
     * @event keyUp-Ctrl+Left 
     */
    function doKeyUpCtrlLeft(UXKeyEvent $e = null)
    {    
        $this->rect7->visible = false;
        $this->label4->opacity = 0.3;
        $this->label5->opacity = 0.3;
        
        $this->rect6->visible = true;
        $this->labelAlt->opacity = 1.0;
        $this->label3->opacity = 1.0;
    }

    /**
     * @event keyUp-Ctrl+Right 
     */
    function doKeyUpCtrlRight(UXKeyEvent $e = null)
    {    
        $this->rect7->visible = true;
        $this->label4->opacity = 1.0;
        $this->label5->opacity = 1.0;
        
        $this->rect6->visible = false;
        $this->labelAlt->opacity = 0.3;
        $this->label3->opacity = 0.3;
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
        app()->showForm('led');
    }

    /**
     * @event rect9.mouseMove 
     */
    function doRect9MouseMove(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(150, function () use ($e, $event) {
			$this->panel->hide();
			waitAsync(1200, function () use ($e, $event) {
				app()->shutdown();
			});
		});

        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(150, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event rect11.click 
     */
    function doRect11Click(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(150, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event rect12.click 
     */
    function doRect12Click(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Animation::fadeOut($this->panel, 130);
		waitAsync(150, function () use ($e, $event) {
			$this->panel->hide();
		});

        
    }

    /**
     * @event rect13.mouseMove 
     */
    function doRect13MouseMove(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {
        Animation::fadeOut($this->panelAlt, 130);
        waitAsync(150, function () use ($e, $event) {
            $this->panelAlt->hide();
            waitAsync(1200, function () use ($e, $event) {
                browse('https://github.com/hentai-team/memphis/blob/main/messages/welcome.md');
            });
        });
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        $verNewGay = file_get_contents('https://raw.githubusercontent.com/hentai-team/memphis/main/versions/latestver.txt');
        
        Animation::fadeOut($this->panelAlt, 130);
        waitAsync(150, function () use ($e, $event) {
            $this->panelAlt->hide();
        });
        browse('https://github.com/hentai-team/memphis/blob/main/versions/latestchanges.md');
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {
        Animation::fadeOut($this->panelAlt, 130);
        waitAsync(150, function () use ($e, $event) {
            $this->panelAlt->hide();
            app()->showForm('exitConfirm');
        });
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {
        Animation::fadeOut($this->panelAlt, 130);
        waitAsync(150, function () use ($e, $event) {
            $this->panelAlt->hide();
            browse('https://github.com/hentai-team/memphis/blob/main/messages/gay.md');
        });
    }






}
