<?php
namespace app\forms;

use std, gui, framework, app;


class about extends AbstractForm
{

    $version = "1.0.010";
    
    
    /**
     * @event circle.click-Left 
     */
    function doCircleClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->hideForm('about');

        
    }

    /**
     * @event circleAlt.click-Left 
     */
    function doCircleAltClickLeft(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->minimizeForm('about');

        
    }




}
