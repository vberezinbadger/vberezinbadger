<?php
namespace fengineeight\modules;

use std, gui, framework, fengineeight;


class AppModule extends AbstractModule
{

}