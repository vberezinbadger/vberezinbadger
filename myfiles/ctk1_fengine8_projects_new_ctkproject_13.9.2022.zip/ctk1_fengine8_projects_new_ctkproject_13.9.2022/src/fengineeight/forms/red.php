<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;


class red extends AbstractForm
{

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseExit 
     */
    function doButtonMouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseDown-Left 
     */
    function doButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button.mouseUp-Left 
     */
    function doButtonMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseEnter 
     */
    function doCircle8MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.mouseExit 
     */
    function doCircle8MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle6.click-Left 
     */
    function doCircle6ClickLeft(UXMouseEvent $e = null)
    {    
        // Изменение элементов формы
        $this->rect8->fillColor = '#808080';
        $this->rectAlt->fillColor = '#f2f2f2';
        $this->rect4->fillColor = '#f2f2f2';
        $this->rect3->fillColor = '#cccccc';
        $this->rect6->fillColor = '#f2f2f2';
        $this->rect7->fillColor = '#e6e6e6';
        $this->rect->fillColor = '#ffffff';
        $this->rect12->fillColor = '#f2f2f2';
        
        // Изменение кнопки INFO
        $this->circle3->fillColor = '#b3b3b3';
        $this->circleAlt->fillColor = '#b3b3b3';
        $this->circle->fillColor = '#b3b3b3';
        
        // Radio-кнопка (показывает выбранный элемент)
        $this->circle5->strokeWidth = 100;
        $this->circle6->strokeWidth = 7;
        $this->circle7->strokeWidth = 100;
        
        // Доступность других Radio-кнопок
        $this->circle5->enabled = true;
        $this->circle6->enabled = false;
        $this->circle7->enabled = true;
    }

    /**
     * @event circle5.click-Left 
     */
    function doCircle5ClickLeft(UXMouseEvent $e = null)
    {    
        // Изменение элементов формы
        $this->rect8->fillColor = '#947070';
        $this->rectAlt->fillColor = '#f2b3b3';
        $this->rect4->fillColor = '#f2b3b3';
        $this->rect3->fillColor = '#dea5a5';
        $this->rect6->fillColor = '#e8d5d5';
        $this->rect7->fillColor = '#d9c8c8';
        $this->rect->fillColor = '#f2e7e7';
        
        // Изменение кнопки INFO
        $this->rect12->fillColor = '#e8d5d5';
        
        // Изменение кнопок управления формой
        $this->circle3->fillColor = '#d27676';
        $this->circleAlt->fillColor = '#d27676';
        $this->circle->fillColor = '#d27676';
        
        // Radio-кнопка (показывает выбранный элемент)
        $this->circle5->strokeWidth = 7;
        $this->circle6->strokeWidth = 100;
        $this->circle7->strokeWidth = 100;
        
        // Доступность других Radio-кнопок
        $this->circle5->enabled = false;
        $this->circle6->enabled = true;
        $this->circle7->enabled = true;
    }

    /**
     * @event circle7.click-Left 
     */
    function doCircle7ClickLeft(UXMouseEvent $e = null)
    {    
        // Изменение элементов формы
        $this->rect8->fillColor = '#496d8c';
        $this->rectAlt->fillColor = '#97bddf';
        $this->rect4->fillColor = '#97bddf';
        $this->rect3->fillColor = '#7b9ebc';
        $this->rect6->fillColor = '#bacdde';
        $this->rect7->fillColor = '#9eb8d0';
        $this->rect->fillColor = '#e6ebee';
        
        // Изменение кнопки INFO
        $this->rect12->fillColor = '#c8d8e7';
        
        // Изменение кнопок управления формой
        $this->circle3->fillColor = '#447cad';
        $this->circleAlt->fillColor = '#447cad';
        $this->circle->fillColor = '#447cad';
        
        // Radio-кнопка (показывает выбранный элемент)
        $this->circle5->strokeWidth = 100;
        $this->circle6->strokeWidth = 100;
        $this->circle7->strokeWidth = 7;
        
        // Доступность других Radio-кнопок
        $this->circle5->enabled = true;
        $this->circle6->enabled = true;
        $this->circle7->enabled = false;
    }

    /**
     * @event circle10.mouseEnter 
     */
    function doCircle10MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.mouseExit 
     */
    function doCircle10MouseExit(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseEnter 
     */
    function doButtonAltMouseEnter(UXMouseEvent $e = null)
    {    
        $this->rect12->strokeColor = '#00000070';
    }

    /**
     * @event buttonAlt.mouseExit 
     */
    function doButtonAltMouseExit(UXMouseEvent $e = null)
    {    
        $this->rect12->strokeColor = '#00000035';
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }











}
