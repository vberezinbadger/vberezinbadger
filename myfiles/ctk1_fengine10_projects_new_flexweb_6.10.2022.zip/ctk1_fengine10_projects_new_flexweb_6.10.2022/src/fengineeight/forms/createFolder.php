<?php
namespace fengineeight\forms;

use std, gui, framework, fengineeight;

use php\gui\UXWebEngine;
use action\Element;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\UXTab;
use php\time\Time;
use php\gui\event\UXEvent;
use php\gui\UXWebView;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;


class createFolder extends AbstractForm
{
    
    /**
     * @event label5.click-Left 
     */
    function doLabel5ClickLeft(UXMouseEvent $e = null)
    {
        $siteOnBaza = file_get_contents('https://kolibra.site/flexweb/webs/sites/sitesCreated/' . $this->edit->text . '');
        
        if ($siteOnBaza == "created=true") {
            app()->hideForm('createFolder');
            $this->form('browser')->browser->engine->url = 'https://kolibra.site/flexweb/webs/sites/' . $this->edit->text . '/main.html';
            Element::setText($this->form('browser')->edit, uiText($this->edit));
            waitAsync(200, function () use ($e, $event) {
                $this->edit->text = '';
                    waitAsync(200, function () use ($e, $event) {
                        $this->form('browser')->browser->engine->reload();
            });});
        } else {
            app()->hideForm('createFolder');
            $this->form('browser')->browser->engine->url = 'https://kolibra.site/flexweb/webs/sites/webs_error404.html';
            $this->form('browser')->edit->text = "Ошибка 404";
            waitAsync(200, function () use ($e, $event) {
                $this->edit->text = '';
                    waitAsync(200, function () use ($e, $event) {
                        $this->form('browser')->browser->engine->reload();
            });});
        }
    }

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->hideForm('createFolder');
        $this->edit->text = '';
    }


}
