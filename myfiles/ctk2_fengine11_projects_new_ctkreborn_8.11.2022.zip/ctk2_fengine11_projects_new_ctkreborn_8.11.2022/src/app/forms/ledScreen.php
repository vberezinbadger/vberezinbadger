<?php
namespace app\forms;

use std, gui, framework, app;


class ledScreen extends AbstractForm
{

    /**
     * @event circle.click-Left 
     */
    function doCircleClickLeft(UXMouseEvent $e = null)
    {    
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle.click-Right 
     */
    function doCircleClickRight(UXMouseEvent $e = null)
    {    
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle9.click-Left 
     */
    function doCircle9ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle9.click-Right 
     */
    function doCircle9ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle17.click-Left 
     */
    function doCircle17ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle17.click-Right 
     */
    function doCircle17ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle25.click-Left 
     */
    function doCircle25ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle25.click-Right 
     */
    function doCircle25ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle33.click-Left 
     */
    function doCircle33ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle33.click-Right 
     */
    function doCircle33ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle41.click-Left 
     */
    function doCircle41ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle41.click-Right 
     */
    function doCircle41ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle49.click-Left 
     */
    function doCircle49ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle49.click-Right 
     */
    function doCircle49ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















    /**
     * @event circle57.click-Left 
     */
    function doCircle57ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle57.click-Right 
     */
    function doCircle57ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circleAlt.click-Left 
     */
    function doCircleAltClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circleAlt.click-Right 
     */
    function doCircleAltClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle3.click-Left 
     */
    function doCircle3ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle3.click-Right 
     */
    function doCircle3ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle4.click-Left 
     */
    function doCircle4ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle4.click-Right 
     */
    function doCircle4ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle5.click-Left 
     */
    function doCircle5ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle5.click-Right 
     */
    function doCircle5ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle6.click-Left 
     */
    function doCircle6ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle6.click-Right 
     */
    function doCircle6ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle7.click-Left 
     */
    function doCircle7ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle7.click-Right 
     */
    function doCircle7ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle8.click-Left 
     */
    function doCircle8ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle8.click-Right 
     */
    function doCircle8ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle10.click-Left 
     */
    function doCircle10ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle10.click-Right 
     */
    function doCircle10ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle11.click-Left 
     */
    function doCircle11ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle11.click-Right 
     */
    function doCircle11ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle12.click-Left 
     */
    function doCircle12ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle12.click-Right 
     */
    function doCircle12ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle13.click-Left 
     */
    function doCircle13ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle13.click-Right 
     */
    function doCircle13ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle14.click-Left 
     */
    function doCircle14ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle14.click-Right 
     */
    function doCircle14ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle15.click-Left 
     */
    function doCircle15ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle15.click-Right 
     */
    function doCircle15ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle16.click-Left 
     */
    function doCircle16ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle16.click-Right 
     */
    function doCircle16ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle18.click-Left 
     */
    function doCircle18ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle18.click-Right 
     */
    function doCircle18ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle19.click-Left 
     */
    function doCircle19ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle19.click-Right 
     */
    function doCircle19ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle20.click-Left 
     */
    function doCircle20ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle20.click-Right 
     */
    function doCircle20ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle21.click-Left 
     */
    function doCircle21ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle21.click-Right 
     */
    function doCircle21ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle22.click-Left 
     */
    function doCircle22ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle22.click-Right 
     */
    function doCircle22ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle23.click-Left 
     */
    function doCircle23ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle23.click-Right 
     */
    function doCircle23ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle24.click-Left 
     */
    function doCircle24ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle24.click-Right 
     */
    function doCircle24ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle26.click-Left 
     */
    function doCircle26ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle26.click-Right 
     */
    function doCircle26ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle27.click-Left 
     */
    function doCircle27ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle27.click-Right 
     */
    function doCircle27ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle28.click-Left 
     */
    function doCircle28ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle28.click-Right 
     */
    function doCircle28ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle29.click-Left 
     */
    function doCircle29ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle29.click-Right 
     */
    function doCircle29ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle30.click-Left 
     */
    function doCircle30ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle30.click-Right 
     */
    function doCircle30ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle31.click-Left 
     */
    function doCircle31ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle31.click-Right 
     */
    function doCircle31ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle32.click-Left 
     */
    function doCircle32ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle32.click-Right 
     */
    function doCircle32ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle34.click-Left 
     */
    function doCircle34ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle34.click-Right 
     */
    function doCircle34ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle35.click-Left 
     */
    function doCircle35ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle35.click-Right 
     */
    function doCircle35ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle36.click-Left 
     */
    function doCircle36ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle36.click-Right 
     */
    function doCircle36ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle37.click-Left 
     */
    function doCircle37ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle37.click-Right 
     */
    function doCircle37ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle38.click-Left 
     */
    function doCircle38ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle38.click-Right 
     */
    function doCircle38ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle39.click-Left 
     */
    function doCircle39ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle39.click-Right 
     */
    function doCircle39ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle40.click-Left 
     */
    function doCircle40ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle40.click-Right 
     */
    function doCircle40ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle42.click-Left 
     */
    function doCircle42ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle42.click-Right 
     */
    function doCircle42ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle43.click-Left 
     */
    function doCircle43ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle43.click-Right 
     */
    function doCircle43ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle44.click-Left 
     */
    function doCircle44ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle44.click-Right 
     */
    function doCircle44ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle45.click-Left 
     */
    function doCircle45ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle45.click-Right 
     */
    function doCircle45ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle46.click-Left 
     */
    function doCircle46ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle46.click-Right 
     */
    function doCircle46ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle47.click-Left 
     */
    function doCircle47ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle47.click-Right 
     */
    function doCircle47ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle48.click-Left 
     */
    function doCircle48ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle48.click-Right 
     */
    function doCircle48ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle50.click-Left 
     */
    function doCircle50ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle50.click-Right 
     */
    function doCircle50ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle51.click-Left 
     */
    function doCircle51ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle51.click-Right 
     */
    function doCircle51ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle52.click-Left 
     */
    function doCircle52ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle52.click-Right 
     */
    function doCircle52ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle53.click-Left 
     */
    function doCircle53ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle53.click-Right 
     */
    function doCircle53ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle54.click-Left 
     */
    function doCircle54ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle54.click-Right 
     */
    function doCircle54ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle55.click-Left 
     */
    function doCircle55ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle55.click-Right 
     */
    function doCircle55ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle56.click-Left 
     */
    function doCircle56ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle56.click-Right 
     */
    function doCircle56ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle58.click-Left 
     */
    function doCircle58ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle58.click-Right 
     */
    function doCircle58ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle59.click-Left 
     */
    function doCircle59ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle59.click-Right 
     */
    function doCircle59ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle60.click-Left 
     */
    function doCircle60ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle60.click-Right 
     */
    function doCircle60ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle61.click-Left 
     */
    function doCircle61ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle61.click-Right 
     */
    function doCircle61ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle62.click-Left 
     */
    function doCircle62ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle62.click-Right 
     */
    function doCircle62ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle63.click-Left 
     */
    function doCircle63ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle63.click-Right 
     */
    function doCircle63ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }

    /**
     * @event circle64.click-Left 
     */
    function doCircle64ClickLeft(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = white;
    }

    /**
     * @event circle64.click-Right 
     */
    function doCircle64ClickRight(UXMouseEvent $e = null)
    {
        $e = $event ?: $e;
        $e->sender->fillColor = '#666666';
    }















































































































































































































































































}
