<?php
namespace app\forms;

use std, gui, framework, app;


class loginForm extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        if(File::of('workspace/users')->isDirectory()) {
            Logger::info('[FLEXengine]: Loaded loginForm!');
            $this->loginForm->show();
        } else {
            $this->loadForm('hterm');
        }
        
    }

    /**
     * @event label3.click-Left 
     */
    function doLabel3ClickLeft(UXMouseEvent $e = null)
    {    
        $username = $this->loginEdit->text;
        
        if (File::of('workspace/users/' . $username . '')->isDirectory()) {
            $this->loginForm->visible = false;
            $this->passForm->visible = true;
            $this->descriptionLabel->visible = false;
        } elseif ($this->loginEdit->text = "") {
            $this->descriptionLabel->visible = true;
            $this->description->text = "Поле логина пустое";
        } else {
            $this->descriptionLabel->visible = true;
            $this->description->text = "Такого пользователя не существует";
        }
    }

    /**
     * @event label20.click-Left 
     */
    function doLabel20ClickLeft(UXMouseEvent $e = null)
    {    
        $username = $this->loginEdit->text;
        
        $password = file_get_contents('workspace/users/' . $username . '/usermgr.password');
        
        if ($this->passwordField->text == $password) {
            $this->loadForm('hterm');
            $this->descriptionLabel->visible = false;
        } elseif ($this->passwordField->text = "") {
            $this->descriptionLabel->visible = true;
            $this->description->text = "Поле с паролем пустое";
        } else {
            $this->descriptionLabel->visible = true;
            $this->description->text = "Неверный пароль";
        }    
    } 
}
