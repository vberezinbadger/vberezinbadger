<?php
namespace app\forms;

use php\gui\UXRichTextArea;
use std, gui, framework, app;
use action\Element; 


class hterm extends AbstractForm
{

    $version = "3.0.010";
    
    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event minButton.click-Left 
     */
    function doMinButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->minimizeForm('hterm');
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }
    
    /**
     * @event labelAlt.mouseDown-Left 
     */
    function doLabelAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.mouseUp-Left 
     */
    function doLabelAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.click-Right 
     */
    function doLabelAltClickRight(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event edit.keyUp-Enter 
     */
    function doEditKeyUpEnter(UXKeyEvent $e = null)
    {    
        $command = $this->edit->text;
        
        switch($command) {
            
            case "clear":
                    $this->edit->clear();
                    $this->textArea->clear();
                    waitAsync(120, function () use ($e, $event) {
                        $this->textArea->appendText("Очистка выполнена! \n", '-fx-font-weight: bold; -fx-fill: #2e3436; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    });
                    $this->outputIcon->sprite->currentAnimation = 'done';
                    break;
            
            case "errortest":
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n⮿ Ошибка в работе. Причина: тестовая ошибка. \n", '-fx-font-weight: bold; -fx-fill: #af4a4a; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'error';
                    break;
                    
            case "goodtest":
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n✓ Выполнено! Вывод: всё круто. \n", '-fx-font-weight: bold; -fx-fill: #2F8032; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'done';
                    break;
                    
            case "documentation":
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n● Просмотрите документацию к Hentai Terminal на сайте:", '-fx-font-weight: bold; -fx-fill: #333333; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\nhttps://vk.com/kolibracorp.hterminal \n", '-fx-font-weight: bold; -fx-fill: #40599e; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'done';
                    break;
                    
            case "outputtest":
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n● Загрузка пакетов Hentai Terminal... Шутка! Это тест! \n", '-fx-font-weight: bold; -fx-fill: #40599e; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'loading';
                    break;
                    
            case "calculator":
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n● Запуск модуля: Калькулятор. \n", '-fx-font-weight: bold; -fx-fill: #40599e; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'loading';
                    app()->showForm('calculator');
                    break;        
                    
            case "logout":
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n● Производим выход из учётной записи Hentai Terminal... \n", '-fx-font-weight: bold; -fx-fill: #40599e; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'loading';
                    $this->form('loginForm')->loginForm->visible = true;
                    $this->form('loginForm')->passForm->visible = false;
                    $this->form('loginForm')->passwordField->text = "";
                    $this->form('loginForm')->loginEdit->text = "";
                    $this->form('loginForm')->descriptionLabel->visible = false;
                    waitAsync(1800, function () use ($e, $event) {
                        $this->loadForm('loginForm');
                    });
                    break;                        
                    
            default:
                    $this->edit->clear();
                    $this->textArea->appendText("\n#: $command", '-fx-font-weight: bold; -fx-fill: #b3b3b3; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->textArea->appendText("\n⮿ Команда недоступна, или не существует! \n", '-fx-font-weight: bold; -fx-fill: #af4a4a; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
                    $this->outputIcon->sprite->currentAnimation = 'error';
                    break;                         
        
        }
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        waitAsync(500, function () use ($e, $event) {
            $this->textArea->editable = true;
            waitAsync(100, function () use ($e, $event) {
                $this->textArea->wrapText = false;
        });});
    }

    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $e = null)
    {    
        $this->textArea = new UXRichTextArea();
        $this->textArea->editable = true;
        $this->textArea->wrapText = false;
        $this->textArea->anchors = ['left' => 30, 'right' => 30, 'top' => 76, 'bottom' => 151];
        $this->textArea->style = '-fx-border-width: 0px; -fx-border-color: silver;';
        $this->textArea->appendText("Hentai Terminal, версия 3.0.010 (ветка: flexengine11_ctk2_dev). \nKolibra Studios, 2022. Все права защищены. \n", '-fx-font-weight: bold; -fx-fill: #333333; -fx-font-family: "Consolas"; -fx-font-size: 14px;');
        $this->add($this->textArea);
    }









}
