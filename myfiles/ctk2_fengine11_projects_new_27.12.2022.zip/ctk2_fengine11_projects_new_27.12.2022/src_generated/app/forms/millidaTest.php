<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 


class millidaTest extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event minButton.click-Left 
     */
    function doMinButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->minimizeForm('millidaTest');
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }





    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        
    }



    /**
     * @event labelAlt.mouseDown-Left 
     */
    function doLabelAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.mouseUp-Left 
     */
    function doLabelAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event labelAlt.click-Right 
     */
    function doLabelAltClickRight(UXMouseEvent $e = null)
    {    
        
    }





}
