from Core.Main import Start

Start(web=False)
