import logging
from telegram.error import TelegramError
from config.settings import GROUP_ID

async def create_order_topic(context, order_id: str, user_id: str, total: float, items: list) -> int:
    try:
        topic_name = f"Заказ #{order_id}"
        user = await context.bot.get_chat_member(chat_id=user_id, user_id=user_id)
        username = user.user.username or user.user.first_name
        
        message = (
            f"📦 Новый заказ #{order_id}\n"
            f"От: @{username} (ID: {user_id})\n"
            f"Сумма: {total}₽\n\n"
            "Товары:\n"
        )
        for item in items:
            message += f"- {item['name']}: {item['price']}₽\n"
        
        topic_msg = await context.bot.create_forum_topic(
            chat_id=GROUP_ID,
            name=topic_name
        )
        
        await context.bot.send_message(
            chat_id=GROUP_ID,
            text=message,
            message_thread_id=topic_msg.message_thread_id
        )
        
        return topic_msg.message_thread_id
    except TelegramError as e:
        logging.error(f"Failed to create order topic: {e}")
        raise

async def create_support_topic(context, user_id: str, message: str) -> int:
    try:
        user = await context.bot.get_chat_member(chat_id=user_id, user_id=user_id)
        username = user.user.username or user.user.first_name
        topic_name = f"Поддержка - {username}"
        
        topic_msg = await context.bot.create_forum_topic(
            chat_id=GROUP_ID,
            name=topic_name
        )
        
        # Send initial support request
        await context.bot.send_message(
            chat_id=GROUP_ID,
            text=f"📞 Обращение в поддержку от @{username}\n\n{message}",
            message_thread_id=topic_msg.message_thread_id
        )
        
        return topic_msg.message_thread_id
    except TelegramError as e:
        logging.error(f"Failed to create support topic: {e}")
        raise