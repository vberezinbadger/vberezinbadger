
from enum import Enum
from typing import Optional, Dict, Any

class Platform(Enum):
    TELEGRAM = "telegram"
    VK = "vk"
    DISCORD = "discord"

class UnifiedMessage:
    def __init__(
        self,
        platform: Platform,
        user_id: str,
        text: str,
        username: Optional[str] = None,
        platform_data: Optional[Dict[str, Any]] = None
    ):
        self.platform = platform
        self.user_id = user_id
        self.text = text
        self.username = username
        self.platform_data = platform_data or {}