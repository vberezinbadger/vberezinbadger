import os
import base64
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Bot configuration
API_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
GROUP_ID = os.getenv('TELEGRAM_GROUP_ID')
STAFF_USERNAMES = os.getenv('STAFF_USERNAMES', '').split(',')

# YooKassa configuration
YOOKASSA_SHOP_ID = os.getenv('YOOKASSA_SHOP_ID')
YOOKASSA_SECRET_KEY = os.getenv('YOOKASSA_SECRET_KEY')

# YooKassa headers
auth_string = f"{YOOKASSA_SHOP_ID}:{YOOKASSA_SECRET_KEY}"
auth_base64 = base64.b64encode(auth_string.encode()).decode()

YOOKASSA_HEADERS = {
    'Authorization': f'Basic {auth_base64}',
    'Content-Type': 'application/json',
    'Idempotence-Key': ''
}