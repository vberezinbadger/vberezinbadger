from enum import Enum
from typing import Union, Optional, Any
import logging
import discord
from telegram import ReplyKeyboardMarkup
import json

class Platform(Enum):
    TELEGRAM = "telegram"
    VK = "vk"
    DISCORD = "discord"

class UnifiedMessage:
    def __init__(
        self,
        platform: Platform,
        user_id: str,
        text: str,
        username: Optional[str] = None,
        platform_data: Optional[dict] = None
    ):
        self.platform = platform
        self.user_id = user_id
        self.text = text
        self.username = username
        self.platform_data = platform_data or {}

class MessageHandler:
    @staticmethod
    async def send_message(
        platform: Platform,
        user_id: str,
        text: str,
        keyboard: Optional[dict] = None,
        context: Optional[dict] = None
    ) -> bool:
        try:
            if platform == Platform.TELEGRAM:
                return await MessageHandler._send_telegram(context['bot'], user_id, text, keyboard)
            elif platform == Platform.VK:
                return await MessageHandler._send_vk(context['vk'], user_id, text, keyboard)
            elif platform == Platform.DISCORD:
                return await MessageHandler._send_discord(context['discord'], user_id, text, keyboard)
            return False
        except Exception as e:
            logging.error(f"Error sending message on {platform}: {e}")
            return False

    @staticmethod
    async def convert_keyboard(platform: Platform, buttons: list) -> Any:
        try:
            if platform == Platform.TELEGRAM:
                return ReplyKeyboardMarkup(buttons, resize_keyboard=True)
            elif platform == Platform.VK:
                vk_keyboard = {
                    "one_time": False,
                    "buttons": [[{"action": {"type": "text", "label": btn}} for btn in row] for row in buttons]
                }
                return json.dumps(vk_keyboard)
            elif platform == Platform.DISCORD:
                return [[discord.Button(label=btn, custom_id=btn.lower()) for btn in row] for row in buttons]
            return None
        except Exception as e:
            logging.error(f"Error converting keyboard for {platform}: {e}")
            return None

    @staticmethod
    async def _send_telegram(bot, user_id: str, text: str, keyboard: Optional[dict] = None):
        return await bot.send_message(chat_id=user_id, text=text, reply_markup=keyboard)

    @staticmethod
    async def _send_vk(vk, user_id: str, text: str, keyboard: Optional[dict] = None):
        try:
            message_data = {
                "message": text,
                "peer_id": int(user_id),
                "random_id": 0
            }
            if keyboard:
                message_data["keyboard"] = keyboard
            return await vk.api.messages.send(**message_data)
        except Exception as e:
            logging.error(f"VK send error: {e}", exc_info=True)
            return False

    @staticmethod
    async def _send_discord(discord, user_id: str, text: str, keyboard: Optional[dict] = None):
        channel = await discord.fetch_channel(int(user_id))
        return await channel.send(text)