import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from models.product import products

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buttons = [
        ['📋 Каталог', '🛒 Корзина'],
        ['📦 Мои заказы', '📞 Поддержка']
    ]
    keyboard = ReplyKeyboardMarkup(buttons, resize_keyboard=True)
    await update.message.reply_text("Добро пожаловать в магазин цифровых услуг!", reply_markup=keyboard)

async def show_catalog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("Цифровые услуги", callback_data="cat_services")],
            [InlineKeyboardButton("Цифровые товары", callback_data="cat_goods")]
        ])
        await update.message.reply_text("Выберите категорию:", reply_markup=keyboard)
    except Exception as e:
        logging.error(f"Error in show_catalog: {e}", exc_info=True)

async def process_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        query = update.callback_query
        await query.answer()
        
        category = query.data.split('_')[1]
        category_key = f'digital_{category}'
        
        if category_key not in products:
            await query.edit_message_text("Категория не найдена!")
            return
            
        category_products = products[category_key]
        keyboard = []
        for pid, product in category_products.items():
            button_text = f"{product['name']} - {product['price']}₽"
            keyboard.append([
                InlineKeyboardButton(button_text, callback_data=f"product_{category}_{pid}")
            ])
        
        keyboard.append([InlineKeyboardButton("« Назад к категориям", callback_data="back_to_cats")])
        
        await query.edit_message_text(
            text=f"Выберите товар из категории {category.title()}:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
            
    except Exception as e:
        logging.error(f"Error in process_category: {e}", exc_info=True)

async def back_to_catalog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Цифровые услуги", callback_data="cat_services")],
        [InlineKeyboardButton("Цифровые товары", callback_data="cat_goods")]
    ])
    
    await query.edit_message_text("Выберите категорию:", reply_markup=keyboard)