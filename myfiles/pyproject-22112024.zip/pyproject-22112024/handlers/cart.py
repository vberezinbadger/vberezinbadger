import logging  # Add this import
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import requests
from datetime import datetime
from config.settings import YOOKASSA_HEADERS
from services.topics import create_order_topic
from models.product import products

# In-memory cart storage
cart = {}

async def show_cart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.message.from_user.id)
    if (user_id not in cart or not cart[user_id]):
        await update.message.reply_text("Ваша корзина пуста!")
        return

    total = sum(item['price'] for item in cart[user_id])
    cart_text = "Ваша корзина:\n\n"
    for item in cart[user_id]:
        cart_text += f"- {item['name']}: {item['price']}₽\n"
    cart_text += f"\nИтого: {total}₽"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Оплатить", callback_data="pay")],
        [InlineKeyboardButton("Очистить корзину", callback_data="clear_cart")]
    ])
    
    await update.message.reply_text(cart_text, reply_markup=keyboard)

async def add_to_cart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        query = update.callback_query
        await query.answer()
        
        _, category, pid = query.data.split('_')
        user_id = str(query.from_user.id)
        
        logging.info(f"Adding to cart: category={category}, pid={pid}")
        
        category_key = f'digital_{category}'
        if category_key not in products:
            logging.error(f"Category {category_key} not found")
            await query.message.reply_text("Category not found!")
            return
            
        if pid not in products[category_key]:
            logging.error(f"Product {pid} not found in {category_key}")
            await query.message.reply_text("Product not found!")
            return
        
        product = products[category_key][pid]
        logging.info(f"Found product: {product}")
        
        if user_id not in cart:
            cart[user_id] = []
        
        cart[user_id].append(product)
        
        await query.message.reply_text(
            f"✅ {product['name']} добавлен в корзину!\n"
            f"Цена: {product['price']}₽"
        )
        
    except Exception as e:
        logging.error(f"Error adding to cart: {e}", exc_info=True)
        await query.message.reply_text("Failed to add product to cart.")

async def clear_cart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = str(query.from_user.id)
    cart[user_id] = []
    await query.message.reply_text("Корзина очищена!")

async def process_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = str(query.from_user.id)
    
    if user_id not in cart or not cart[user_id]:
        await query.answer("Ваша корзина пуста!")
        return
    
    total = sum(item['price'] for item in cart[user_id])
    order_id = f"ЗАКАЗ-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    # Create order topic
    topic_id = await create_order_topic(context, order_id, user_id, total, cart[user_id])
    
    # Prepare payment data
    payment_data = {
        "amount": {
            "value": str(total),
            "currency": "RUB"
        },
        "confirmation": {
            "type": "redirect",
            "return_url": "https://your-redirect-url.com"
        },
        "capture": True,
        "description": f"Order {order_id}"
    }
    
    # Send payment request to YooKassa
    response = requests.post(
        "https://api.yookassa.ru/v3/payments",
        headers=YOOKASSA_HEADERS,
        json=payment_data
    )
    
    if response.status_code == 200:
        payment_info = response.json()
        confirmation_url = payment_info["confirmation"]["confirmation_url"]
        
        await query.message.reply_text(
            f"Заказ {order_id} создан.\n"
            f"Сумма к оплате: {total}₽\n"
            f"Для оплаты перейдите по ссылке: {confirmation_url}"
        )
        
        # Clear the cart after initiating payment
        cart[user_id] = []
    else:
        await query.message.reply_text("Ошибка при создании платежа. Попробуйте еще раз.")