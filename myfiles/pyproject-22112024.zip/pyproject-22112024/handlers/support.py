from typing import Union
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.error import TelegramError
from telegram.constants import ParseMode
from config.settings import GROUP_ID, STAFF_USERNAMES
from services.topics import create_support_topic
from models.message import UnifiedMessage, Platform
from handlers.platform_handlers import MessageHandler
import logging

__all__ = ['support_topics', 'contact_support', 'process_support_message', 
           'handle_staff_support_reply', 'close_support_topic_callback']

# In-memory storage for support topics
support_topics = {}

async def contact_support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = str(update.message.from_user.id)
        
        # Check if user already has an active support topic
        if user_id in support_topics and support_topics[user_id].get('active'):
            await update.message.reply_text(
                "У вас уже есть активный диалог с поддержкой. "
                "Просто отправьте сообщение, и мы ответим."
            )
            return

        # Set support mode in user data
        context.user_data['support_mode'] = True
        support_topics[user_id] = {
            'active': True,
            'topic_id': None  # Will be set when first message is sent
        }
        
        await update.message.reply_text(
            "Опишите вашу проблему, и служба поддержки скоро ответит.\n"
            "Вы можете отправить несколько сообщений."
        )

    except Exception as e:
        logging.error(f"Error in contact_support: {e}", exc_info=True)
        await update.message.reply_text("Произошла ошибка. Попробуйте позже.")

async def process_support_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        message = update.message
        user_id = str(message.from_user.id)
        
        # Create new topic if needed
        if (user_id not in support_topics or 
            not support_topics[user_id].get('active') or 
            support_topics[user_id].get('topic_id') is None):
            
            # Create topic with initial text message
            initial_text = message.caption or message.text or "Новое обращение в поддержку"
            topic_id = await create_support_topic(context, user_id, initial_text)
            support_topics[user_id] = {
                'topic_id': topic_id,
                'active': True
            }
            
            # Forward media if present
            if message.photo:
                await context.bot.send_photo(
                    chat_id=GROUP_ID,
                    photo=message.photo[-1].file_id,
                    caption=message.caption,
                    message_thread_id=topic_id
                )
            elif message.video:
                await context.bot.send_video(
                    chat_id=GROUP_ID,
                    video=message.video.file_id,
                    caption=message.caption,
                    message_thread_id=topic_id
                )
            elif message.document:
                await context.bot.send_document(
                    chat_id=GROUP_ID,
                    document=message.document.file_id,
                    caption=message.caption,
                    message_thread_id=topic_id
                )
            elif message.voice:
                await context.bot.send_voice(
                    chat_id=GROUP_ID,
                    voice=message.voice.file_id,
                    caption=message.caption,
                    message_thread_id=topic_id
                )
            elif message.audio:
                await context.bot.send_audio(
                    chat_id=GROUP_ID,
                    audio=message.audio.file_id,
                    caption=message.caption,
                    message_thread_id=topic_id
                )

            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("❌ Закрыть диалог", callback_data="close_support")]
            ])
            await message.reply_text(
                "Ваш запрос создан. Служба поддержки скоро ответит.",
                reply_markup=keyboard
            )
            return

        # Forward regular messages to existing topic
        topic_id = support_topics[user_id]['topic_id']
        customer_name = message.from_user.username or message.from_user.first_name

        # Forward media with caption
        if message.photo:
            await context.bot.send_photo(
                chat_id=GROUP_ID,
                photo=message.photo[-1].file_id,
                caption=f"💬 Клиент @{customer_name}:\n{message.caption or ''}",
                message_thread_id=topic_id
            )
        elif message.video:
            await context.bot.send_video(
                chat_id=GROUP_ID,
                video=message.video.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{message.caption or ''}",
                message_thread_id=topic_id
            )
        elif message.document:
            await context.bot.send_document(
                chat_id=GROUP_ID,
                document=message.document.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{message.caption or ''}",
                message_thread_id=topic_id
            )
        elif message.voice:
            await context.bot.send_voice(
                chat_id=GROUP_ID,
                voice=message.voice.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{message.caption or ''}",
                message_thread_id=topic_id
            )
        elif message.audio:
            await context.bot.send_audio(
                chat_id=GROUP_ID,
                audio=message.audio.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{message.caption or ''}",
                message_thread_id=topic_id
            )
        elif message.text:
            await context.bot.send_message(
                chat_id=GROUP_ID,
                text=f"💬 Клиент @{customer_name}:\n{message.text}",
                message_thread_id=topic_id
            )

        # Show close button
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Закрыть диалог", callback_data="close_support")]
        ])
        await message.reply_text(
            "✅ Сообщение отправлено в поддержку.",
            reply_markup=keyboard
        )

    except Exception as e:
        logging.error(f"Error in process_support_message: {e}")
        await message.reply_text("Произошла ошибка. Попробуйте еще раз.")

# Remove handle_staff_support_reply as it's now handled in orders.py

async def close_support_topic_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle support closing from inline button"""
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    
    if user_id not in support_topics or not support_topics[user_id].get('active'):
        await query.message.reply_text("No active support conversation found.")
        return
        
    topic_id = support_topics[user_id]['topic_id']
    
    # Mark as inactive and clear support mode
    support_topics[user_id]['active'] = False
    if 'support_mode' in context.user_data:
        del context.user_data['support_mode']
    
    # Notify user and restore main keyboard
    buttons = [
        ['📋 Каталог', '🛒 Корзина'],
        ['📦 Мои заказы', '📞 Поддержка']
    ]
    keyboard = ReplyKeyboardMarkup(buttons, resize_keyboard=True)
    
    await query.message.reply_text(
        "Диалог с поддержкой закрыт.\n"
        "Чтобы начать новый, нажмите кнопку Поддержка.",
        reply_markup=keyboard
    )
    
    # Notify staff and delete topic
    try:
        await context.bot.send_message(
            chat_id=GROUP_ID,
            text="✅ Support conversation closed by customer.",
            message_thread_id=topic_id
        )
        await context.bot.delete_forum_topic(
            chat_id=GROUP_ID,
            message_thread_id=topic_id
        )
    except TelegramError as e:
        logging.error(f"Failed to delete support topic: {e}")