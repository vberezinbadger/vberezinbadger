from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ForceReply
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from telegram.error import TelegramError
from services.topics import create_order_topic
from config.settings import GROUP_ID, STAFF_USERNAMES
import logging
import json
from datetime import datetime
from handlers.support import support_topics, process_support_message  # Add this import
from typing import Union
from models.message import UnifiedMessage, Platform

# In-memory storage (can be replaced with a database)
orders = {}

# Handler functions
async def handle_staff_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        message = update.message
        logging.info("=== Debug Info ===")
        logging.info(f"All orders: {json.dumps(orders, indent=2)}")
        logging.info(f"Support topics: {support_topics}")
        logging.info(f"Current topic_id: {message.message_thread_id}")
        logging.info(f"Processing message in chat {message.chat.id} from user {message.from_user.username}")
        logging.info(f"Message thread ID: {message.message_thread_id}")
        
        # Basic validation with logging
        if not message or not message.chat:
            logging.warning("No message or chat found")
            return
            
        # Only process messages in the designated group
        if str(message.chat.id) != GROUP_ID:
            logging.info(f"Message not in target group. Got {message.chat.id}, expected {GROUP_ID}")
            return

        # Only process messages in topics
        if not message.message_thread_id:
            logging.info("Message not in a topic")
            return
            
        # Don't process bot's own messages
        if message.from_user.id == context.bot.id:
            logging.info("Skipping bot's own message")
            return

        # Check if sender is authorized staff
        if message.from_user.username not in STAFF_USERNAMES:
            logging.warning(f"Unauthorized reply attempt from {message.from_user.username}")
            await message.reply_text("You are not authorized to respond to orders.")
            return

        topic_id = message.message_thread_id
        staff_name = message.from_user.first_name

        # First check support topics
        user_id = next(
            (uid for uid, data in support_topics.items() 
             if data.get('topic_id') == topic_id and data.get('active')),
            None
        )
        
        if user_id:
            # Handle as support message
            if message.photo:
                media_caption = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{message.caption or ''}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_photo(
                    chat_id=user_id,
                    photo=message.photo[-1].file_id,
                    caption=media_caption,
                    parse_mode=ParseMode.HTML
                )
            elif message.video:
                media_caption = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{message.caption or ''}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_video(
                    chat_id=user_id,
                    video=message.video.file_id,
                    caption=media_caption,
                    parse_mode=ParseMode.HTML
                )
            elif message.document:
                media_caption = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{message.caption or ''}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_document(
                    chat_id=user_id,
                    document=message.document.file_id,
                    caption=media_caption,
                    parse_mode=ParseMode.HTML
                )
            elif message.voice:
                media_caption = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{message.caption or 'Голосовое сообщение'}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_voice(
                    chat_id=user_id,
                    voice=message.voice.file_id,
                    caption=media_caption,
                    parse_mode=ParseMode.HTML
                )
            elif message.audio:
                media_caption = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{message.caption or 'Аудио сообщение'}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_audio(
                    chat_id=user_id,
                    audio=message.audio.file_id,
                    caption=media_caption,
                    parse_mode=ParseMode.HTML
                )
            elif message.text:
                text_message = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{message.text}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_message(
                    chat_id=user_id,
                    text=text_message,
                    parse_mode=ParseMode.HTML
                )
            
            await message.reply_text(
                "✅ Сообщение отправлено клиенту",
                message_thread_id=topic_id
            )
            return

        # Then check orders if not found in support
        user_id = None
        order_info = None
        for uid, user_orders in orders.items():
            for order in user_orders:
                logging.info(f"Comparing topic_id {topic_id} with order topic_id {order.get('topic_id')}")
                if int(order.get('topic_id', 0)) == int(topic_id):
                    user_id = uid
                    order_info = order
                    break
            if user_id:
                break

        if not user_id:
            logging.warning(f"No order found for topic {topic_id}")
            await message.reply_text("Cannot find associated order for this topic.")
            return

        # Handle media messages from staff
        if user_id:
            staff_name = message.from_user.first_name
            content = message.caption if message.caption else message.text

            # For media messages
            if message.photo or message.video or message.document or message.voice or message.audio:
                media_caption = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{content}\n\n"
                    "Для ответа отправьте новое сообщение."
                )

                if message.photo:
                    await context.bot.send_photo(
                        chat_id=user_id,
                        photo=message.photo[-1].file_id,
                        caption=media_caption,
                        parse_mode=ParseMode.HTML
                    )
                elif message.video:
                    await context.bot.send_video(
                        chat_id=user_id,
                        video=message.video.file_id,
                        caption=media_caption,
                        parse_mode=ParseMode.HTML
                    )
                elif message.document:
                    await context.bot.send_document(
                        chat_id=user_id,
                        document=message.document.file_id,
                        caption=media_caption,
                        parse_mode=ParseMode.HTML
                    )
                elif message.voice:
                    await context.bot.send_voice(
                        chat_id=user_id,
                        voice=message.voice.file_id,
                        caption=media_caption or "Голосовое сообщение",
                        parse_mode=ParseMode.HTML
                    )
                elif message.audio:
                    await context.bot.send_audio(
                        chat_id=user_id,
                        audio=message.audio.file_id,
                        caption=media_caption or "Аудио сообщение",
                        parse_mode=ParseMode.HTML
                    )
            else:
                # For text-only messages
                response_text = (
                    f"💬 Сотрудник поддержки {staff_name}:\n"
                    f"{content or '...'}\n\n"
                    "Для ответа отправьте новое сообщение."
                )
                await context.bot.send_message(
                    chat_id=user_id,
                    text=response_text,
                    parse_mode=ParseMode.HTML
                )

            await message.reply_text(
                "✅ Сообщение отправлено клиенту",
                message_thread_id=topic_id
            )
            return

        # Forward the response to the customer without Complete Order button
        response_text = (
            f"💬 Ответ от {staff_name} (Заказ #{order_info['id']}):\n"
            f"{message.text}\n\n"
            "Для ответа сотруднику отправьте новое сообщение.\n"
            "Используйте кнопку '✅ Завершить заказ', когда захотите закрыть заказ."
        )
        
        # Send message to customer without keyboard
        sent_message = await context.bot.send_message(
            chat_id=user_id,
            text=response_text,
            parse_mode=ParseMode.HTML
        )
        
        # Confirm in the topic that message was sent
        await message.reply_text(
            "✅ Response sent to customer",
            message_thread_id=topic_id
        )
        
        logging.info(f"Successfully sent staff reply to user {user_id} from topic {topic_id}")
        
    except TelegramError as e:
        logging.error(f"Failed to send staff reply: {e}")
        await message.reply_text(
            "Error: Failed to deliver message to customer.",
            message_thread_id=topic_id
        )

async def handle_customer_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        message = update.message
        user_id = str(message.from_user.id)
        
        # Enhanced debug logging
        logging.info("=== Customer Message Debug ===")
        logging.info(f"Message from user: {user_id}")
        logging.info(f"Message text: {message.text}")
        logging.info(f"Orders for user: {json.dumps(orders.get(user_id, []))}")
        
        # Check if user has any active orders
        if user_id not in orders or not orders[user_id]:
            await message.reply_text("У вас нет активных заказов.")
            return
            
        # Get the latest active order
        active_order = next(
            (order for order in reversed(orders[user_id]) 
             if order['status'] != 'completed'), 
            None
        )
        
        if not active_order:
            await message.reply_text("У вас нет активных заказов.")
            return

        # Get message content
        content = None
        if message.text:
            content = message.text
        elif message.caption:
            content = message.caption
            
        # Forward the message to the topic
        customer_name = message.from_user.username or message.from_user.first_name

        # Handle media messages
        if message.photo:
            await context.bot.send_photo(
                chat_id=GROUP_ID,
                photo=message.photo[-1].file_id,
                caption=f"💬 Клиент @{customer_name}:\n{content or ''}\n\nЗаказ: #{active_order['id']}",
                message_thread_id=active_order['topic_id']
            )
        elif message.video:
            await context.bot.send_video(
                chat_id=GROUP_ID,
                video=message.video.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{content or ''}\n\nЗаказ: #{active_order['id']}",
                message_thread_id=active_order['topic_id']
            )
        elif message.document:
            await context.bot.send_document(
                chat_id=GROUP_ID,
                document=message.document.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{content or ''}\n\nЗаказ: #{active_order['id']}",
                message_thread_id=active_order['topic_id']
            )
        elif message.voice:
            await context.bot.send_voice(
                chat_id=GROUP_ID,
                voice=message.voice.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{content or 'Голосовое сообщение'}\n\nЗаказ: #{active_order['id']}",
                message_thread_id=active_order['topic_id']
            )
        elif message.audio:
            await context.bot.send_audio(
                chat_id=GROUP_ID,
                audio=message.audio.file_id,
                caption=f"💬 Клиент @{customer_name}:\n{content or 'Аудио сообщение'}\n\nЗаказ: #{active_order['id']}",
                message_thread_id=active_order['topic_id']
            )
        else:
            # Text message
            await context.bot.send_message(
                chat_id=GROUP_ID,
                text=f"💬 Клиент @{customer_name}:\n{content or '...'}\n\nЗаказ: #{active_order['id']}",
                message_thread_id=active_order['topic_id']
            )

        # Show order completion button
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Завершить заказ", callback_data=f"complete_order_{active_order['id']}")]
        ])
        
        await message.reply_text(
            "✅ Ваше сообщение отправлено.\n"
            "Нажмите кнопку ниже, когда захотите завершить заказ:",
            reply_markup=keyboard
        )
            
    except Exception as e:
        logging.error(f"Error in customer message: {e}")
        await message.reply_text("Произошла ошибка. Попробуйте позже.")

async def complete_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    # Extract order ID from callback data
    order_id = query.data.split('_')[2]
    user_id = str(query.from_user.id)
    
    # Find and update order status
    for order in orders.get(user_id, []):
        if order['id'] == order_id:
            order['status'] = 'completed'
            await query.edit_message_text(
                f"Заказ #{order_id} завершен.\n\n"
                "Спасибо за использование нашего сервиса!"
            )
            
            # Notify in the topic
            await context.bot.send_message(
                chat_id=GROUP_ID,
                text=f"✅ Order #{order_id} has been marked as completed by the customer.",
                message_thread_id=order['topic_id']
            )
            return

    await query.message.reply_text("Order not found.")

async def handle_complete_order_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = str(update.message.from_user.id)
        
        # Find latest active order
        active_order = next(
            (order for order in reversed(orders.get(user_id, []))
             if order['status'] != 'completed'),
            None
        )
        
        if not active_order:
            await update.message.reply_text("You don't have any active orders to complete.")
            return
            
        # Update order status
        active_order['status'] = 'completed'
        topic_id = active_order['topic_id']
        
        # Notify user
        await update.message.reply_text(
            f"Order #{active_order['id']} has been marked as completed.\n"
            "Thank you for using our service!"
        )
        
        # Notify in the topic and then delete it
        try:
            await context.bot.send_message(
                chat_id=GROUP_ID,
                text=f"✅ Order #{active_order['id']} has been marked as completed by the customer.",
                message_thread_id=topic_id
            )
            
            # Delete the topic
            await context.bot.delete_forum_topic(
                chat_id=GROUP_ID,
                message_thread_id=topic_id
            )
            logging.info(f"Successfully deleted topic {topic_id} for order {active_order['id']}")
            
        except TelegramError as e:
            logging.error(f"Failed to delete topic: {e}")
            # Continue even if topic deletion fails
            pass
            
    except Exception as e:
        logging.error(f"Error completing order: {e}")
        await update.message.reply_text("An error occurred while completing the order.")

async def test_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = str(update.message.from_user.id)
        
        # Create sample order data
        test_items = [
            {'name': 'Test Product 1', 'price': 100},
            {'name': 'Test Product 2', 'price': 200}
        ]
        total = sum(item['price'] for item in test_items)
        order_id = f"TEST-{datetime.now().strftime('%Y%m%d%H%M%S')}"

        # Create topic using the updated function
        topic_id = await create_order_topic(context, order_id, user_id, total, test_items)
        
        # Store the test order in orders dictionary
        if user_id not in orders:
            orders[user_id] = []
        
        orders[user_id].append({
            'id': order_id,
            'date': datetime.now().isoformat(),
            'status': 'test_order',
            'items': test_items,
            'total': total,
            'topic_id': topic_id
        })
        
        await update.message.reply_text(
            f"Test order created!\n"
            f"Order ID: {order_id}\n"
            f"Topic ID: {topic_id}"
        )
        
        logging.info(f"Test order created with topic ID: {topic_id}")
        # Debug print orders
        logging.info(f"Current orders: {json.dumps(orders, indent=2)}")
    
    except TelegramError as e:
        logging.error(f"Failed to create test order: {e}")
        await update.message.reply_text("Failed to create test order.")

async def show_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.message.from_user.id)
    if user_id not in orders or not orders[user_id]:
        await update.message.reply_text("У вас пока нет заказов!")
        return

    orders_text = "Ваши заказы:\n\n"
    for order in orders[user_id]:
        status_map = {
            'completed': 'завершён',
            'pending': 'в обработке',
            'test_order': 'тестовый'
        }
        status = status_map.get(order['status'], order['status'])
        orders_text += f"Номер заказа: {order['id']}\n"
        orders_text += f"Дата: {order['date']}\n"
        orders_text += f"Статус: {status}\n\n"
    
    await update.message.reply_text(orders_text)

async def handle_user_message(update: Union[Update, UnifiedMessage], context: ContextTypes.DEFAULT_TYPE):
    """Route messages to either support or order handling"""
    try:
        # Handle both Telegram Update and UnifiedMessage objects
        if isinstance(update, Update):
            user_id = str(update.message.from_user.id)
            text = update.message.text
            platform = Platform.TELEGRAM
        else:  # UnifiedMessage
            user_id = update.user_id
            text = update.text
            platform = update.platform
        
        logging.info(f"Routing message for user {user_id} on platform {platform}")
        logging.info(f"Support topics: {support_topics}")
        logging.info(f"Orders: {orders.get(user_id, [])}")
        
        # Check if user is in support mode
        if context and hasattr(context, 'user_data') and 'support_mode' in context.user_data:
            logging.info(f"Processing support message for user {user_id}")
            await process_support_message(update, context)
            return
            
        # Check for active support conversation
        if user_id in support_topics and support_topics[user_id].get('active'):
            logging.info(f"Routing to support for user {user_id}")
            await process_support_message(update, context)
            return
            
        # Then check for active orders
        active_order = next(
            (order for order in reversed(orders.get(user_id, []))
             if order['status'] != 'completed'),
            None
        )
        
        if active_order:
            logging.info(f"Routing to order {active_order['id']} for user {user_id}")
            await handle_customer_message(update, context)
            return

        # Platform-specific responses for no active conversations
        if platform == Platform.TELEGRAM:
            await update.message.reply_text(
                "Нет активных заказов или диалогов с поддержкой.\n"
                "Используйте кнопку 📞 Поддержка или оформите заказ."
            )
        elif platform == Platform.VK:
            await context['vk'].api.messages.send(
                peer_id=int(user_id),
                message="No active orders or support conversations.\n"
                       "Start a support chat or place an order first.",
                random_id=0
            )
        elif platform == Platform.DISCORD:
            channel = await context['discord'].fetch_channel(int(user_id))
            await channel.send(
                "No active orders or support conversations.\n"
                "Start a support chat or place an order first."
            )
            
    except Exception as e:
        logging.error(f"Error routing user message: {e}", exc_info=True)
        # Platform-specific error responses
        try:
            if isinstance(update, Update):
                await update.message.reply_text("An error occurred. Please try again.")
            elif update.platform == Platform.VK:
                await context['vk'].api.messages.send(
                    peer_id=int(update.user_id),
                    message="An error occurred. Please try again.",
                    random_id=0
                )
            elif update.platform == Platform.DISCORD:
                channel = await context['discord'].fetch_channel(int(update.user_id))
                await channel.send("An error occurred. Please try again.")
        except Exception as e2:
            logging.error(f"Error sending error message: {e2}", exc_info=True)