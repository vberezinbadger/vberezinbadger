import logging
import asyncio
from telegram.ext import (
    ApplicationBuilder, 
    CommandHandler, 
    MessageHandler, 
    CallbackQueryHandler, 
    filters
)
from config.settings import API_TOKEN, GROUP_ID
from handlers.orders import (
    handle_staff_reply, 
    test_order, 
    show_orders, 
    handle_customer_message,
    handle_complete_order_request,
    handle_user_message
)
from handlers.cart import show_cart, add_to_cart, process_payment, clear_cart
from handlers.catalog import start, show_catalog, process_category, back_to_catalog
from handlers.support import (
    contact_support, 
    process_support_message, 
    close_support_topic_callback
)

def setup_handlers(application):
    # Basic handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("test_order", test_order))
    
    # Menu button handlers
    application.add_handler(MessageHandler(filters.Regex("^📋 Каталог$"), show_catalog))
    application.add_handler(MessageHandler(filters.Regex("^🛒 Корзина$"), show_cart))
    application.add_handler(MessageHandler(filters.Regex("^📦 Мои заказы$"), show_orders))
    application.add_handler(MessageHandler(filters.Regex("^📞 Поддержка$"), contact_support))
    
    # Staff handler in group
    application.add_handler(MessageHandler(
        filters.Chat(chat_id=int(GROUP_ID)) & filters.TEXT & ~filters.COMMAND,
        handle_staff_reply
    ))
    
    # Support and order completion handlers
    application.add_handler(CallbackQueryHandler(close_support_topic_callback, pattern="^close_support$"))
    application.add_handler(CallbackQueryHandler(handle_complete_order_request, pattern="^complete_order_"))
    
    # Catalog and product handlers
    application.add_handler(CallbackQueryHandler(process_category, pattern="^cat_"))
    application.add_handler(CallbackQueryHandler(add_to_cart, pattern="^product_"))
    application.add_handler(CallbackQueryHandler(back_to_catalog, pattern="^back_to_cats$"))  # Fixed extra CallbackQueryHandler
    
    # Add media message handlers for both support and orders
    application.add_handler(MessageHandler(
        (filters.PHOTO | filters.VIDEO | filters.Document.ALL | filters.VOICE | filters.AUDIO) & 
        filters.Chat(chat_id=int(GROUP_ID)),
        handle_staff_reply
    ))
    
    application.add_handler(MessageHandler(
        filters.PHOTO | filters.VIDEO | filters.Document.ALL | filters.VOICE | filters.AUDIO,
        handle_user_message
    ))
    
    # Generic message handler for both support and orders
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & 
        ~filters.Regex("^(📋 Каталог|🛒 Корзина|📦 Мои заказы|📞 Поддержка)$"),
        handle_user_message
    ))

def main():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    application = ApplicationBuilder().token(API_TOKEN).build()
    setup_handlers(application)
    
    try:
        application.run_polling()
    except KeyboardInterrupt:
        logging.info("Bot stopped by user")
    except Exception as e:
        logging.error(f"Fatal error: {e}")

if __name__ == '__main__':
    main()