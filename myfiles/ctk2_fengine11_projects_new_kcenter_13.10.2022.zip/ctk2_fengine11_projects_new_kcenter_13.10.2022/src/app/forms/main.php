<?php
namespace app\forms;

use std, gui, framework, app;


class main extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }

    /**
     * @event minButton.click-Left 
     */
    function doMinButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->minimizeForm('main');
    }

    /**
     * @event closeButton.click-Left 
     */
    function doCloseButtonClickLeft(UXMouseEvent $e = null)
    {    
        app()->shutdown();
    }




    /**
     * @event label3.click 
     */
    function doLabel3Click(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event rectAlt.click 
     */
    function doRectAltClick(UXMouseEvent $e = null)
    {    
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event label4.click 
     */
    function doLabel4Click(UXMouseEvent $e = null)
    {
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event label5.click 
     */
    function doLabel5Click(UXMouseEvent $e = null)
    {
        $this->rect3->strokeWidth = 0;
        $this->rect3->strokeColor = '#cccccc';
        $this->rect3->fillColor = '#e6e6e6';
        $this->edit->focusTraversable = false;
    }

    /**
     * @event labelAlt.mouseDown-Left 
     */
    function doLabelAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->label4->text = "onWindowBlinkFX_enabled: true";
        $this->label5->text = "onMouseAttached_status: 0x01";
    }

    /**
     * @event labelAlt.mouseUp-Left 
     */
    function doLabelAltMouseUpLeft(UXMouseEvent $e = null)
    {    
        $this->label4->text = "onWindowBlinkFX_enabled: false";
        $this->label5->text = "onMouseAttached_status: 0x00";
    }

    /**
     * @event labelAlt.click-Right 
     */
    function doLabelAltClickRight(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->rect10->x = 32;
        $this->rect10->y = 32;
        $this->image5->x = 40;
        $this->image5->y = 40;
        
        $this->labelAlt->text = "               Kolibra Center";
    }

    /**
     * @event label9.click-Left 
     */
    function doLabel9ClickLeft(UXMouseEvent $e = null)
    {    
        $this->rect10->x = 72;
        $this->rect10->y = 32;
        $this->image5->x = 80;
        $this->image5->y = 40;
        
        $this->labelAlt->text = "                          Kolibra Center";
        
        $this->rect9->visible = true;
        $this->image4->visible = true;
        
        $this->panel->visible = true;
    }

    /**
     * @event image4.click-Left 
     */
    function doImage4ClickLeft(UXMouseEvent $e = null)
    {    
        $this->rect10->x = 32;
        $this->rect10->y = 32;
        $this->image5->x = 40;
        $this->image5->y = 40;
        
        $this->labelAlt->text = "               Kolibra Center";
        
        $this->rect9->visible = false;
        $this->image4->visible = false;
        
        $this->panel->visible = false;
    }

    /**
     * @event rect9.click-Left 
     */
    function doRect9ClickLeft(UXMouseEvent $e = null)
    {    
        $this->rect10->x = 32;
        $this->rect10->y = 32;
        $this->image5->x = 40;
        $this->image5->y = 40;
        
        $this->labelAlt->text = "               Kolibra Center";
        
        $this->rect9->visible = false;
        $this->image4->visible = false;
        
        $this->panel->visible = false;
    }

    /**
     * @event rect12.mouseMove 
     */
    function doRect12MouseMove(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect13.mouseMove 
     */
    function doRect13MouseMove(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect14.mouseMove 
     */
    function doRect14MouseMove(UXMouseEvent $e = null)
    {    
        
    }





}
