<?php
namespace app\forms;

use std, gui, framework, app;


class loaderDark extends AbstractForm
{

    /**
     * @event image.mouseMove 
     */
    function doImageMouseMove(UXMouseEvent $e = null)
    {    
        
    }

}
